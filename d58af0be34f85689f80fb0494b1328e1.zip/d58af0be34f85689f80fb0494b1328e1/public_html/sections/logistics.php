<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">🚚 Управление логистикой</h1>
    <div>
        <button class="btn btn-outline-secondary" onclick="loadLogisticsData()">
            🔄 Обновить
        </button>
    </div>
</div>

<!-- Поиск и фильтры -->
<div class="card mb-4">
    <div class="card-header bg-light">
        <h5 class="mb-0">🔍 Поиск по логистике</h5>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-md-3">
                <div class="mb-3">
                    <label class="form-label">Поиск по клиенту</label>
                    <input type="text" class="form-control" id="logisticsSearchClient" 
                           placeholder="Введите ФИО клиента..." oninput="filterLogisticsTable()">
                </div>
            </div>
            <div class="col-md-3">
                <div class="mb-3">
                    <label class="form-label">Поиск по партнеру</label>
                    <input type="text" class="form-control" id="logisticsSearchPartner" 
                           placeholder="Введите партнера..." oninput="filterLogisticsTable()">
                </div>
            </div>
            <div class="col-md-3">
                <div class="mb-3">
                    <label class="form-label">Поиск по банку</label>
                    <input type="text" class="form-control" id="logisticsSearchBank" 
                           placeholder="Введите банк..." oninput="filterLogisticsTable()">
                </div>
            </div>
            <div class="col-md-3">
                <div class="mb-3">
                    <label class="form-label">Способ доставки</label>
                    <select class="form-select" id="logisticsSearchType" onchange="filterLogisticsTable()">
                        <option value="">Все способы</option>
                    </select>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <button class="btn btn-outline-secondary btn-sm" onclick="clearLogisticsSearch()">
                    🗑️ Очистить поиск
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Статистика -->
<div class="row mb-4">
    <div class="col-md-3">
        <div class="card bg-warning text-white">
            <div class="card-body text-center">
                <h6>Ожидают доставки</h6>
                <h3 id="pendingLogisticsCount">0</h3>
                <small>Всего сделок</small>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-success text-white">
            <div class="card-body text-center">
                <h6>Завершено доставок</h6>
                <h3 id="completedLogisticsCount">0</h3>
                <small>Всего сделок</small>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-info text-white">
            <div class="card-body text-center">
                <h6>Почтовые отправления</h6>
                <h3 id="postalLogisticsCount">0</h3>
                <small>С трек номерами</small>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-primary text-white">
            <div class="card-body text-center">
                <h6>СМС подписание</h6>
                <h3 id="smsLogisticsCount">0</h3>
                <small>Мгновенные сделки</small>
            </div>
        </div>
    </div>
</div>

<!-- Основная таблица -->
<div class="card">
    <div class="card-header">
        <h5 class="mb-0">📋 Сделки, ожидающие доставки документов</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>Дата</th>
                        <th>Клиент</th>
                        <th>Партнер</th>
                        <th>Банк</th>
                        <th>Способ доставки</th>
                        <th>Трек номер</th>
                        <th>Менеджер</th>
                        <th>Статус</th>
                        <th>Действия</th>
                    </tr>
                </thead>
                <tbody id="logisticsTable">
                    <tr><td colspan="9" class="text-center py-4">Загрузка данных...</td></tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
// Глобальные переменные для логистики
let logisticsDeals = [];
let filteredLogisticsDeals = [];

// Инициализация логистики
function initLogistics() {
    console.log('Initializing logistics...');
    loadLogisticsData();
    populateLogisticsFilters();
}

// Загрузка данных логистики
function loadLogisticsData() {
    console.log('Loading logistics data...');
    
    const tbody = document.getElementById('logisticsTable');
    if (tbody) {
        tbody.innerHTML = '<tr><td colspan="9" class="text-center py-4"><div class="spinner-border"></div><p class="mt-2">Загрузка данных логистики...</p></td></tr>';
    }
    
    // Используем уже загруженные deals из main.js
    if (window.deals && Array.isArray(window.deals)) {
        processLogisticsData(window.deals);
    } else {
        // Если deals еще не загружены, ждем и пробуем снова
        setTimeout(() => {
            if (window.deals && Array.isArray(window.deals)) {
                processLogisticsData(window.deals);
            } else {
                console.error('Deals data not available');
                if (tbody) {
                    tbody.innerHTML = '<tr><td colspan="9" class="text-center py-4 text-danger">Ошибка загрузки данных</td></tr>';
                }
            }
        }, 1000);
    }
}

// Обработка данных для логистики
function processLogisticsData(dealsData) {
    console.log('Processing logistics data:', dealsData.length, 'deals');
    
    // Фильтруем сделки по статусу pending (ожидают доставки)
    logisticsDeals = dealsData.filter(deal => deal.status === 'pending');
    filteredLogisticsDeals = [...logisticsDeals];
    
    console.log('Pending deals for logistics:', logisticsDeals.length);
    
    updateLogisticsStats();
    updateLogisticsTable();
    populateLogisticsFilters();
}

// Обновление статистики
function updateLogisticsStats() {
    const pendingCount = logisticsDeals.length;
    const completedCount = window.deals ? window.deals.filter(deal => deal.status === 'completed').length : 0;
    const postalCount = logisticsDeals.filter(deal => deal.logistics === 'Почта').length;
    const smsCount = window.deals ? window.deals.filter(deal => deal.logistics === 'СМС подписание').length : 0;
    
    document.getElementById('pendingLogisticsCount').textContent = pendingCount;
    document.getElementById('completedLogisticsCount').textContent = completedCount;
    document.getElementById('postalLogisticsCount').textContent = postalCount;
    document.getElementById('smsLogisticsCount').textContent = smsCount;
}

// Обновление таблицы логистики
function updateLogisticsTable() {
    const tbody = document.getElementById('logisticsTable');
    if (!tbody) return;
    
    if (filteredLogisticsDeals.length === 0) {
        tbody.innerHTML = '<tr><td colspan="9" class="text-center py-4">Нет сделок, ожидающих доставки документов</td></tr>';
        return;
    }
    
    tbody.innerHTML = filteredLogisticsDeals.map(deal => `
        <tr>
            <td>${formatDate(deal.auth_date)}</td>
            <td><strong>${escapeHtml(deal.client_name)}</strong></td>
            <td>${escapeHtml(deal.partner)}</td>
            <td><span class="badge bg-info">${escapeHtml(deal.bank)}</span></td>
            <td>${escapeHtml(deal.logistics)}</td>
            <td>${deal.track_number ? `<code>${escapeHtml(deal.track_number)}</code>` : '<span class="text-muted">Не указан</span>'}</td>
            <td><span class="badge bg-primary">${escapeHtml(deal.manager)}</span></td>
            <td><span class="badge bg-warning">Ожидает доставки</span></td>
            <td>
                ${window.currentUserRole === 'admin' || window.currentUserRole === 'logistics' ? 
                    `<button class="btn btn-sm btn-success" onclick="markAsDelivered(${deal.id})" title="Отметить как доставлено">
                        ✅ Доставлено
                    </button>` :
                    `<span class="text-muted">Только для логиста</span>`
                }
            </td>
        </tr>
    `).join('');
}

// Заполнение фильтров
function populateLogisticsFilters() {
    const logisticsTypeSelect = document.getElementById('logisticsSearchType');
    if (!logisticsTypeSelect) return;
    
    // Получаем уникальные способы доставки из всех сделок
    const logisticsTypes = [...new Set(window.deals.map(deal => deal.logistics).filter(Boolean))];
    
    logisticsTypeSelect.innerHTML = '<option value="">Все способы</option>';
    logisticsTypes.forEach(type => {
        const option = document.createElement('option');
        option.value = type;
        option.textContent = type;
        logisticsTypeSelect.appendChild(option);
    });
}

// Фильтрация таблицы
function filterLogisticsTable() {
    const clientQuery = document.getElementById('logisticsSearchClient').value.toLowerCase();
    const partnerQuery = document.getElementById('logisticsSearchPartner').value.toLowerCase();
    const bankQuery = document.getElementById('logisticsSearchBank').value.toLowerCase();
    const logisticsType = document.getElementById('logisticsSearchType').value;
    
    filteredLogisticsDeals = logisticsDeals.filter(deal => {
        const clientMatch = !clientQuery || 
            (deal.client_name && deal.client_name.toLowerCase().includes(clientQuery));
        const partnerMatch = !partnerQuery || 
            (deal.partner && deal.partner.toLowerCase().includes(partnerQuery));
        const bankMatch = !bankQuery || 
            (deal.bank && deal.bank.toLowerCase().includes(bankQuery));
        const typeMatch = !logisticsType || deal.logistics === logisticsType;
        
        return clientMatch && partnerMatch && bankMatch && typeMatch;
    });
    
    updateLogisticsTable();
}

// Очистка поиска
function clearLogisticsSearch() {
    document.getElementById('logisticsSearchClient').value = '';
    document.getElementById('logisticsSearchPartner').value = '';
    document.getElementById('logisticsSearchBank').value = '';
    document.getElementById('logisticsSearchType').value = '';
    
    filteredLogisticsDeals = [...logisticsDeals];
    updateLogisticsTable();
}

// Вспомогательные функции
function formatDate(dateString) {
    try {
        const date = new Date(dateString);
        return date.toLocaleDateString('ru-RU');
    } catch (e) {
        return dateString;
    }
}

function escapeHtml(text) {
    if (text === null || text === undefined) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Инициализация при загрузке страницы
if (document.getElementById('logisticsTable')) {
    document.addEventListener('DOMContentLoaded', function() {
        setTimeout(initLogistics, 500);
    });
    
    // Также инициализируем при показе раздела
    const originalShowSection = window.showSection;
    window.showSection = function(sectionId) {
        originalShowSection(sectionId);
        if (sectionId === 'logistics') {
            setTimeout(initLogistics, 100);
        }
    };
}
</script>