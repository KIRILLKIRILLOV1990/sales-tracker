<?php
// sections/partners.php - БЕЗОПАСНАЯ ВЕРСИЯ
?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">🏢 Управление партнерами</h1>
    <div>
        <button class="btn btn-success me-2" onclick="exportPartners()">
            📊 Выгрузить в Excel
        </button>
        <button class="btn btn-primary" onclick="showPartnerForm()">
            ➕ Добавить партнера
        </button>
    </div>
</div>

<!-- Форма добавления/редактирования -->
<div id="partnerFormSection" class="card mb-4" style="display: none;">
    <div class="card-header">
        <h5 class="mb-0" id="partnerFormTitle">Добавить партнера</h5>
    </div>
    <div class="card-body">
        <form id="partnerForm">
            <input type="hidden" id="partnerId">
            
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label class="form-label">Название партнера *</label>
                        <input type="text" class="form-control" id="partnerName" required>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label class="form-label">ИНН</label>
                        <input type="text" class="form-control" id="partnerInn" maxlength="20" placeholder="10 или 12 цифр">
                    </div>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label class="form-label">Контактное лицо</label>
                        <input type="text" class="form-control" id="partnerContactPerson" placeholder="ФИО контактного лица">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label class="form-label">Телефон</label>
                        <input type="tel" class="form-control" id="partnerPhone" placeholder="+7 (XXX) XXX-XX-XX">
                    </div>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" class="form-control" id="partnerEmail" placeholder="email@example.com">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label class="form-label">Адрес</label>
                        <textarea class="form-control" id="partnerAddress" rows="2" placeholder="Юридический адрес"></textarea>
                    </div>
                </div>
            </div>
            
            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-success">💾 Сохранить</button>
                <button type="button" class="btn btn-secondary" onclick="hidePartnerForm()">Отмена</button>
            </div>
        </form>
    </div>
</div>

<!-- Поиск и фильтры -->
<div class="card mb-4">
    <div class="card-header bg-light">
        <h5 class="mb-0">🔍 Поиск партнеров</h5>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-md-4">
                <div class="mb-3">
                    <label class="form-label">Поиск по названию</label>
                    <input type="text" class="form-control" id="searchPartnerName" placeholder="Введите название..." oninput="searchPartners()">
                </div>
            </div>
            <div class="col-md-4">
                <div class="mb-3">
                    <label class="form-label">Поиск по ИНН</label>
                    <input type="text" class="form-control" id="searchPartnerInn" placeholder="Введите ИНН..." oninput="searchPartners()">
                </div>
            </div>
            <div class="col-md-4">
                <div class="mb-3">
                    <label class="form-label">Поиск по контактному лицу</label>
                    <input type="text" class="form-control" id="searchPartnerContact" placeholder="Введите ФИО..." oninput="searchPartners()">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <button class="btn btn-outline-secondary btn-sm" onclick="clearPartnerSearch()">
                    🗑️ Очистить поиск
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Таблица партнеров -->
<div class="card">
    <div class="card-header">
        <h5 class="mb-0">Список партнеров</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>Название</th>
                        <th>ИНН</th>
                        <th>Контактное лицо</th>
                        <th>Телефон</th>
                        <th>Email</th>
                        <th>Действия</th>
                    </tr>
                </thead>
                <tbody id="partnersTable">
                    <tr><td colspan="6" class="text-center py-4">Загрузка данных...</td></tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
// partners.js - управление партнерами - БЕЗОПАСНАЯ ВЕРСИЯ

let allPartners = [];
let filteredPartners = [];

// БЕЗОПАСНАЯ функция экранирования HTML
function escapeHtml(text) {
    if (text === null || text === undefined) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Безопасное создание HTML из данных
function createSafePartnerRow(partner) {
    const row = document.createElement('tr');
    
    // Безопасное заполнение данных
    const cells = [
        escapeHtml(partner.name),
        partner.inn ? escapeHtml(partner.inn) : '-',
        partner.contact_person ? escapeHtml(partner.contact_person) : '-',
        partner.phone ? `<a href="tel:${escapeHtml(partner.phone)}">${escapeHtml(partner.phone)}</a>` : '-',
        partner.email ? `<a href="mailto:${escapeHtml(partner.email)}">${escapeHtml(partner.email)}</a>` : '-'
    ];
    
    cells.forEach(cellContent => {
        const td = document.createElement('td');
        td.innerHTML = cellContent;
        row.appendChild(td);
    });
    
    // Кнопки действий
    const actionsTd = document.createElement('td');
    actionsTd.innerHTML = `
        <div class="btn-group btn-group-sm">
            <button class="btn btn-outline-primary" onclick="editPartner(${partner.id})" title="Редактировать">
                ✏️
            </button>
            <button class="btn btn-outline-danger" onclick="deletePartner(${partner.id}, '${escapeHtml(partner.name).replace(/'/g, "\\'")}')" title="Удалить">
                🗑️
            </button>
        </div>
    `;
    row.appendChild(actionsTd);
    
    return row;
}

// Загрузка партнеров
function loadPartners() {
    showPartnersLoading(true);
    
    fetch('api.php?action=get_partners')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                allPartners = data.partners;
                filteredPartners = [...allPartners];
                displayPartnersTable(filteredPartners);
            } else {
                throw new Error(data.error || 'Failed to load partners');
            }
            showPartnersLoading(false);
        })
        .catch(error => {
            console.error('Error:', error);
            showPartnersLoading(false);
            const tbody = document.getElementById('partnersTable');
            tbody.innerHTML = '<tr><td colspan="6" class="text-center py-4 text-danger">Ошибка загрузки: ' + escapeHtml(error.message) + '</td></tr>';
        });
}

// БЕЗОПАСНОЕ отображение таблицы партнеров
function displayPartnersTable(partners) {
    const tbody = document.getElementById('partnersTable');
    tbody.innerHTML = '';
    
    if (partners.length === 0) {
        const row = document.createElement('tr');
        row.innerHTML = '<td colspan="6" class="text-center py-4">Нет данных о партнерах</td>';
        tbody.appendChild(row);
        return;
    }
    
    partners.forEach(partner => {
        const row = createSafePartnerRow(partner);
        tbody.appendChild(row);
    });
}

// Поиск партнеров
function searchPartners() {
    const nameQuery = document.getElementById('searchPartnerName').value.toLowerCase();
    const innQuery = document.getElementById('searchPartnerInn').value.toLowerCase();
    const contactQuery = document.getElementById('searchPartnerContact').value.toLowerCase();
    
    filteredPartners = allPartners.filter(partner => {
        const nameMatch = !nameQuery || (partner.name && partner.name.toLowerCase().includes(nameQuery));
        const innMatch = !innQuery || (partner.inn && partner.inn.toLowerCase().includes(innQuery));
        const contactMatch = !contactQuery || (partner.contact_person && partner.contact_person.toLowerCase().includes(contactQuery));
        
        return nameMatch && innMatch && contactMatch;
    });
    
    displayPartnersTable(filteredPartners);
}

// Очистка поиска
function clearPartnerSearch() {
    document.getElementById('searchPartnerName').value = '';
    document.getElementById('searchPartnerInn').value = '';
    document.getElementById('searchPartnerContact').value = '';
    filteredPartners = [...allPartners];
    displayPartnersTable(filteredPartners);
}

// Показать форму добавления
function showPartnerForm() {
    document.getElementById('partnerFormSection').style.display = 'block';
    document.getElementById('partnerFormTitle').textContent = 'Добавить партнера';
    document.getElementById('partnerForm').reset();
    document.getElementById('partnerId').value = '';
    
    // Прокрутка к форме
    document.getElementById('partnerFormSection').scrollIntoView({ behavior: 'smooth' });
}

// Скрыть форму
function hidePartnerForm() {
    document.getElementById('partnerFormSection').style.display = 'none';
}

// Редактирование партнера
function editPartner(partnerId) {
    fetch(`api.php?action=get_partner&id=${partnerId}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const partner = data.partner;
                
                // Безопасное заполнение формы
                document.getElementById('partnerId').value = partner.id;
                document.getElementById('partnerName').value = partner.name || '';
                document.getElementById('partnerInn').value = partner.inn || '';
                document.getElementById('partnerContactPerson').value = partner.contact_person || '';
                document.getElementById('partnerPhone').value = partner.phone || '';
                document.getElementById('partnerEmail').value = partner.email || '';
                document.getElementById('partnerAddress').value = partner.address || '';
                
                document.getElementById('partnerFormTitle').textContent = 'Редактировать партнера';
                document.getElementById('partnerFormSection').style.display = 'block';
                
                // Прокрутка к форме
                document.getElementById('partnerFormSection').scrollIntoView({ behavior: 'smooth' });
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Ошибка загрузки данных партнера: ' + error.message);
        });
}

// Удаление партнера
function deletePartner(partnerId, partnerName) {
    if (!confirm(`Вы уверены, что хотите удалить партнера "${partnerName}"?`)) {
        return;
    }
    
    const formData = new FormData();
    formData.append('action', 'delete_partner');
    formData.append('id', partnerId);

    fetch('api.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Партнер успешно удален!');
            loadPartners();
        } else {
            alert('Ошибка при удалении: ' + data.error);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Ошибка при удалении: ' + error.message);
    });
}

// Сохранение партнера
function savePartner() {
    const partnerId = document.getElementById('partnerId').value;
    const isEditing = partnerId !== '';
    
    const formData = new FormData();
    formData.append('action', isEditing ? 'update_partner' : 'add_partner');
    
    if (isEditing) {
        formData.append('id', partnerId);
    }
    
    formData.append('name', document.getElementById('partnerName').value);
    formData.append('inn', document.getElementById('partnerInn').value);
    formData.append('phone', document.getElementById('partnerPhone').value);
    formData.append('email', document.getElementById('partnerEmail').value);
    formData.append('contact_person', document.getElementById('partnerContactPerson').value);
    formData.append('address', document.getElementById('partnerAddress').value);

    fetch('api.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert(isEditing ? 'Партнер успешно обновлен!' : 'Партнер успешно добавлен!');
            hidePartnerForm();
            loadPartners();
        } else {
            alert('Ошибка при сохранении: ' + data.error);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Ошибка при сохранении: ' + error.message);
    });
}

// Экспорт партнеров
function exportPartners() {
    if (filteredPartners.length === 0) {
        alert('Нет данных для экспорта');
        return;
    }
    
    let csv = "Название;ИНН;Контактное лицо;Телефон;Email;Адрес\n";
    
    filteredPartners.forEach(partner => {
        // Безопасный экспорт - экранируем кавычки
        const safeName = (partner.name || '').replace(/"/g, '""');
        const safeInn = (partner.inn || '').replace(/"/g, '""');
        const safeContact = (partner.contact_person || '').replace(/"/g, '""');
        const safePhone = (partner.phone || '').replace(/"/g, '""');
        const safeEmail = (partner.email || '').replace(/"/g, '""');
        const safeAddress = (partner.address || '').replace(/"/g, '""');
        
        csv += `"${safeName}";"${safeInn}";"${safeContact}";"${safePhone}";"${safeEmail}";"${safeAddress}"\n`;
    });
    
    // Создаем и скачиваем файл
    const blob = new Blob(["\uFEFF" + csv], { 
        type: 'text/csv;charset=utf-8;' 
    });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    
    link.setAttribute('href', url);
    link.setAttribute('download', 'партнеры_' + new Date().toISOString().slice(0, 10) + '.csv');
    link.style.display = 'none';
    
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// Вспомогательные функции
function showPartnersLoading(show) {
    const tbody = document.getElementById('partnersTable');
    if (show) {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center py-4"><div class="spinner-border"></div><p class="mt-2">Загрузка...</p></td></tr>';
    }
}

// Инициализация при загрузке страницы
document.addEventListener('DOMContentLoaded', function() {
    // Обработчик формы
    const partnerForm = document.getElementById('partnerForm');
    if (partnerForm) {
        partnerForm.addEventListener('submit', function(e) {
            e.preventDefault();
            savePartner();
        });
    }
    
    // Загружаем партнеров если мы на нужной странице
    if (document.getElementById('partnersTable')) {
        loadPartners();
    }
});
</script>