<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2" id="dealFormTitle">Добавить успешную сделку</h1>
    <button class="btn btn-secondary" onclick="resetDealForm();">
        🔄 Новая сделка
    </button>
</div>

<form id="dealForm">
    <input type="hidden" id="dealId" value="">
    <div class="form-section">
        <h5>Основная информация</h5>
        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                    <label class="form-label">Партнер *</label>
                    <select class="form-select" id="dealPartner" required>
                        <option value="">Выберите партнера</option>
                    </select>
                </div>
            </div>
            <div class="col-md-6">
                <div class="mb-3">
                    <label class="form-label">Юридическое лицо *</label>
                    <select class="form-select" id="dealLegalEntity" required>
                        <option value="">Выберите юр. лицо</option>
                    </select>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                    <label class="form-label">ФИО клиента *</label>
                    <input type="text" class="form-control" id="clientName" required>
                </div>
            </div>
            <div class="col-md-6">
                <div class="mb-3">
                    <label class="form-label">Страна *</label>
                    <select class="form-select" id="dealCountry" required>
                        <option value="">Выберите страну</option>
                    </select>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                    <label class="form-label">Дата авторизации *</label>
                    <input type="date" class="form-control" id="authDate" required>
                </div>
            </div>
            <div class="col-md-6">
                <div class="mb-3">
                    <label class="form-label">Номер договора *</label>
                    <input type="text" class="form-control" id="contractNumber" required>
                </div>
            </div>
        </div>
    </div>

    <div class="form-section">
        <h5>Финансовая информация</h5>
        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                    <label class="form-label">Банк *</label>
                    <select class="form-select" id="dealBank" required>
                        <option value="">Выберите банк</option>
                    </select>
                </div>
            </div>
            <div class="col-md-6">
                <div class="mb-3">
                    <label class="form-label">Процентная ставка *</label>
                    <input type="number" class="form-control" id="interestRate" step="0.01" required>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="mb-3">
                    <label class="form-label">Срок рассрочки *</label>
                    <select class="form-select" id="installmentPeriod" required>
                        <option value="">Выберите срок</option>
                        <option value="6">6 месяцев</option>
                        <option value="10">10 месяцев</option>
                        <option value="12">12 месяцев</option>
                        <option value="18">18 месяцев</option>
                        <option value="24">24 месяца</option>
                        <option value="36">36 месяцев</option>
                    </select>
                </div>
            </div>
            <div class="col-md-4">
                <div class="mb-3">
                    <label class="form-label">Сумма договора *</label>
                    <input type="number" class="form-control" id="contractAmount" required>
                </div>
            </div>
            <div class="col-md-4">
                <div class="mb-3">
                    <label class="form-label">Сумма информирования *</label>
                    <input type="number" class="form-control" id="infoAmount" required>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                    <label class="form-label">Сумма без информирования *</label>
                    <input type="number" class="form-control" id="noInfoAmount" required>
                </div>
            </div>
            <div class="col-md-6">
                <div class="mb-3">
                    <label class="form-label">Сумма в валюте</label>
                    <input type="number" class="form-control" id="currencyAmount" placeholder="Для международных сделок">
                </div>
            </div>
        </div>
    </div>

    <div class="form-section">
        <h5>Логистика и контакты</h5>
        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                    <label class="form-label">Логистика *</label>
                    <select class="form-select" id="dealLogistics" required onchange="toggleTrackNumber()">
                        <option value="">Выберите способ</option>
                    </select>
                </div>
            </div>
            <div class="col-md-6">
                <div class="mb-3">
                    <label class="form-label">Менеджер *</label>
                    <select class="form-select" id="dealManager" required>
                        <option value="">Выберите менеджера</option>
                    </select>
                </div>
            </div>
        </div>
        <div class="row" id="trackNumberSection" style="display: none;">
            <div class="col-12">
                <div class="mb-3">
                    <label class="form-label">Трек номер</label>
                    <input type="text" class="form-control" id="trackNumber" placeholder="Введите трек номер">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                    <label class="form-label">Email клиента</label>
                    <input type="email" class="form-control" id="clientEmail">
                </div>
            </div>
            <div class="col-md-6">
                <div class="mb-3">
                    <label class="form-label">Телефон клиента</label>
                    <input type="tel" class="form-control" id="clientPhone">
                </div>
            </div>
        </div>
    </div>

    <div class="d-grid gap-2 d-md-flex justify-content-md-end mt-4">
        <button type="submit" class="btn btn-success btn-lg">💾 Сохранить сделку</button>
        <button type="button" class="btn btn-secondary btn-lg" onclick="showSection('deals')">Отмена</button>
    </div>
</form>