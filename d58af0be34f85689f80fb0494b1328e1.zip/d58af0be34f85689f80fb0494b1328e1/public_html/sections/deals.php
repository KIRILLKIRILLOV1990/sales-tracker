<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Все успешные сделки</h1>
    <div>
        <button class="btn btn-success me-2" onclick="exportToExcel()" id="exportBtn">
            📊 Выгрузить в Excel
        </button>
        <button class="btn btn-primary me-2" onclick="showSection('add-deal'); resetDealForm();">
            ➕ Новая сделка
        </button>
        <button class="btn btn-outline-secondary" onclick="loadAllData()">
            🔄 Обновить
        </button>
    </div>
</div>

<!-- ПАНЕЛЬ ПОИСКА -->
<div class="card mb-4">
    <div class="card-header bg-light">
        <h5 class="mb-0">🔍 Поиск сделок</h5>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-md-4">
                <div class="mb-3">
                    <label class="form-label">Поиск по ФИО клиента</label>
                    <input type="text" class="form-control" id="searchClientName" 
                           placeholder="Введите ФИО клиента..." oninput="applySearch()">
                </div>
            </div>
            <div class="col-md-4">
                <div class="mb-3">
                    <label class="form-label">Быстрый поиск по менеджеру</label>
                    <select class="form-select" id="searchManager" onchange="applySearch()">
                        <option value="">Все менеджеры</option>
                    </select>
                </div>
            </div>
            <div class="col-md-4">
                <div class="mb-3">
                    <label class="form-label">Статус сделки</label>
                    <select class="form-select" id="searchStatus" onchange="applySearch()">
                        <option value="">Все статусы</option>
                        <option value="completed">Завершено</option>
                        <option value="pending">В процессе</option>
                    </select>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <button class="btn btn-outline-secondary btn-sm" onclick="clearSearch()">
                    🗑️ Очистить поиск
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Фильтр по периоду для сделок -->
<div class="period-filter card mb-4">
    <div class="card-header bg-light">
        <h5 class="mb-0">📅 Фильтр по периоду</h5>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-md-3">
                <div class="mb-3">
                    <label class="form-label">Дата с</label>
                    <input type="date" class="form-control" id="dealsDateFrom">
                </div>
            </div>
            <div class="col-md-3">
                <div class="mb-3">
                    <label class="form-label">Дата по</label>
                    <input type="date" class="form-control" id="dealsDateTo">
                </div>
            </div>
            <div class="col-md-3">
                <div class="mb-3">
                    <label class="form-label">Быстрый выбор</label>
                    <select class="form-select" id="dealsQuickPeriod" onchange="applyDealsQuickPeriod()">
                        <option value="">Выберите период</option>
                        <option value="today">Сегодня</option>
                        <option value="yesterday">Вчера</option>
                        <option value="week">Текущая неделя</option>
                        <option value="month" selected>Текущий месяц</option>
                        <option value="quarter">Текущий квартал</option>
                        <option value="year">Текущий год</option>
                        <option value="lastMonth">Прошлый месяц</option>
                        <option value="lastQuarter">Прошлый квартал</option>
                        <option value="lastYear">Прошлый год</option>
                    </select>
                </div>
            </div>
            <div class="col-md-3 d-flex align-items-end">
                <div class="mb-3 w-100">
                    <button class="btn btn-primary w-100" onclick="applyDealsDateFilter()">Применить фильтр</button>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="form-text">
                    <span id="dealsPeriodInfo">Показаны все данные</span>
                    <button class="btn btn-sm btn-outline-secondary ms-2" onclick="clearDealsDateFilter()">Очистить фильтр</button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ИНФОРМАЦИЯ О РЕЗУЛЬТАТАХ ПОИСКА -->
<div class="alert alert-info d-flex justify-content-between align-items-center" id="searchResultsInfo" style="display: none !important;">
    <div>
        <span id="searchResultsText"></span>
    </div>
    <button class="btn btn-sm btn-outline-info" onclick="clearSearch()">
        Сбросить поиск
    </button>
</div>

<div class="table-responsive">
    <table class="table table-striped table-hover">
        <thead>
            <tr>
                <th>#</th>
                <th>Дата</th>
                <th>Партнер</th>
                <th>Клиент</th>
                <th>Банк</th>
                <th>Сумма договора</th>
                <th>Сумма информирования</th>
                <th>Сумма без информирования</th>
                <th>Ставка</th>
                <th>Срок рассрочки</th>
                <th>Номер договора</th>
                <th>Страна</th>
                <th>Email клиента</th>
                <th>Телефон клиента</th>
                <th>Менеджер</th>
                <th>Логистика</th>
                <th>Действия</th>
            </tr>
        </thead>
        <tbody id="dealsTable">
            <tr><td colspan="17" class="text-center py-4">Загрузка данных...</td></tr>
        </tbody>
    </table>
</div>

<!-- ПАГИНАЦИЯ -->
<nav aria-label="Навигация по страницам" id="dealsPagination">
    <!-- Пагинация будет генерироваться JavaScript -->
</nav>