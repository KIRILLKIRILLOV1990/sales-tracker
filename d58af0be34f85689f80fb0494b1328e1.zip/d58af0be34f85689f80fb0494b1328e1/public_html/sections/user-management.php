<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Управление пользователями</h1>
</div>

<div class="row">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Добавить пользователя</h5>
            </div>
            <div class="card-body">
                <form id="userForm">
                    <input type="hidden" id="userId" value="">
                    
                    <div class="mb-3">
                        <label class="form-label">ФИО</label>
                        <input type="text" class="form-control" id="fullName" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Логин</label>
                        <input type="text" class="form-control" id="username" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Пароль</label>
                        <input type="password" class="form-control" id="password" required>
                        <div class="form-text">Минимум 6 символов</div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Роль</label>
                        <select class="form-select" id="userRole" required>
                            <option value="">Выберите роль</option>
                            <option value="admin">Администратор</option>
                            <option value="manager">Менеджер</option>
                            <option value="logistics">Логист</option>
                        </select>
                    </div>
                    
                    <div class="mb-3 form-check">
                        <input type="checkbox" class="form-check-input" id="isActive" checked>
                        <label class="form-check-label" for="isActive">Активный пользователь</label>
                    </div>
                    
                    <button type="submit" class="btn btn-success" id="saveUserBtn">Добавить пользователя</button>
                    <button type="button" class="btn btn-secondary" id="cancelEditBtn" style="display: none;">Отмена</button>
                </form>
            </div>
        </div>
    </div>
    
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Список пользователей</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>ФИО</th>
                                <th>Логин</th>
                                <th>Роль</th>
                                <th>Статус</th>
                                <th>Действия</th>
                            </tr>
                        </thead>
                        <tbody id="usersTable">
                            <tr><td colspan="5" class="text-center py-4">Загрузка...</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.getElementById('userForm').addEventListener('submit', function(e) {
    e.preventDefault();
    saveUser();
});

function loadUsers() {
    fetch('api.php?action=get_users')
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                alert('Ошибка: ' + data.error);
                return;
            }
            
            const tbody = document.getElementById('usersTable');
            if (data.users.length === 0) {
                tbody.innerHTML = '<tr><td colspan="5" class="text-center py-4">Нет пользователей</td></tr>';
            } else {
                tbody.innerHTML = data.users.map(user => `
                    <tr>
                        <td>${user.full_name}</td>
                        <td>${user.username}</td>
                        <td>${getRoleName(user.role)}</td>
                        <td>${user.is_active ? '<span class="badge bg-success">Активен</span>' : '<span class="badge bg-danger">Неактивен</span>'}</td>
                        <td>
                            <button class="btn btn-sm btn-outline-primary" onclick="editUser(${user.id})">✏️</button>
                            ${user.id !== <?php echo $current_user['id']; ?> ? 
                                `<button class="btn btn-sm btn-outline-danger" onclick="deleteUser(${user.id}, '${user.full_name.replace(/'/g, "\\'")}')">🗑️</button>` : 
                                '<span class="text-muted">Текущий</span>'
                            }
                        </td>
                    </tr>
                `).join('');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Ошибка загрузки пользователей');
        });
}

function getRoleName(role) {
    const roles = {
        'admin': 'Администратор',
        'manager': 'Менеджер', 
        'logistics': 'Логист'
    };
    return roles[role] || role;
}

function saveUser() {
    const formData = new FormData();
    formData.append('action', 'save_user');
    formData.append('user_id', document.getElementById('userId').value);
    formData.append('full_name', document.getElementById('fullName').value);
    formData.append('username', document.getElementById('username').value);
    formData.append('password', document.getElementById('password').value);
    formData.append('role', document.getElementById('userRole').value);
    formData.append('is_active', document.getElementById('isActive').checked ? '1' : '0');

    fetch('api.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            alert('Ошибка: ' + data.error);
        } else {
            alert('Пользователь сохранен!');
            resetUserForm();
            loadUsers();
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Ошибка сохранения пользователя');
    });
}

function editUser(userId) {
    fetch(`api.php?action=get_user&user_id=${userId}`)
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                alert('Ошибка: ' + data.error);
                return;
            }
            
            const user = data.user;
            document.getElementById('userId').value = user.id;
            document.getElementById('fullName').value = user.full_name;
            document.getElementById('username').value = user.username;
            document.getElementById('password').required = false;
            document.getElementById('userRole').value = user.role;
            document.getElementById('isActive').checked = user.is_active;
            
            document.getElementById('saveUserBtn').textContent = 'Обновить пользователя';
            document.getElementById('cancelEditBtn').style.display = 'inline-block';
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Ошибка загрузки пользователя');
        });
}

function deleteUser(userId, userName) {
    if (!confirm(`Удалить пользователя "${userName}"?`)) return;
    
    const formData = new FormData();
    formData.append('action', 'delete_user');
    formData.append('user_id', userId);

    fetch('api.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            alert('Ошибка: ' + data.error);
        } else {
            alert('Пользователь удален!');
            loadUsers();
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Ошибка удаления пользователя');
    });
}

function resetUserForm() {
    document.getElementById('userForm').reset();
    document.getElementById('userId').value = '';
    document.getElementById('password').required = true;
    document.getElementById('saveUserBtn').textContent = 'Добавить пользователя';
    document.getElementById('cancelEditBtn').style.display = 'none';
}

document.getElementById('cancelEditBtn').addEventListener('click', resetUserForm);

// Загружаем пользователей при открытии раздела
loadUsers();
</script>