<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Настройки системы</h1>
    <button class="btn btn-outline-secondary" onclick="loadAllData()">
        🔄 Обновить
    </button>
</div>

<div class="row">
    <!-- Партнеры -->
    <div class="col-md-6">
        <div class="card settings-card">
            <div class="card-header bg-primary text-white">
                <h6 class="mb-0">🏢 Партнеры</h6>
            </div>
            <div class="card-body">
                <div class="input-group mb-3">
                    <input type="text" class="form-control" id="newPartner" placeholder="Введите название партнера">
                    <button class="btn btn-success" type="button" onclick="addPartner()">Добавить</button>
                </div>
                <div class="settings-list" id="partnersList">
                    <div class="text-muted text-center p-3">Загрузка...</div>
                </div>
            </div>
        </div>
    </div>

    <!-- Банки -->
    <div class="col-md-6">
        <div class="card settings-card">
            <div class="card-header bg-success text-white">
                <h6 class="mb-0">🏦 Банки</h6>
            </div>
            <div class="card-body">
                <div class="input-group mb-3">
                    <input type="text" class="form-control" id="newBank" placeholder="Введите название банка">
                    <button class="btn btn-success" type="button" onclick="addBank()">Добавить</button>
                </div>
                <div class="settings-list" id="banksList">
                    <div class="text-muted text-center p-3">Загрузка...</div>
                </div>
            </div>
        </div>
    </div>

    <!-- Юридические лица -->
    <div class="col-md-6">
        <div class="card settings-card">
            <div class="card-header bg-warning text-dark">
                <h6 class="mb-0">⚖️ Юридические лица</h6>
            </div>
            <div class="card-body">
                <div class="input-group mb-3">
                    <input type="text" class="form-control" id="newLegalEntity" placeholder="Введите название юр. лица">
                    <button class="btn btn-success" type="button" onclick="addLegalEntity()">Добавить</button>
                </div>
                <div class="settings-list" id="legalEntitiesList">
                    <div class="text-muted text-center p-3">Загрузка...</div>
                </div>
            </div>
        </div>
    </div>

    <!-- Менеджеры -->
    <div class="col-md-6">
        <div class="card settings-card">
            <div class="card-header bg-info text-white">
                <h6 class="mb-0">👨‍💼 Менеджеры</h6>
            </div>
            <div class="card-body">
                <div class="input-group mb-3">
                    <input type="text" class="form-control" id="newManager" placeholder="Введите ФИО менеджера">
                    <button class="btn btn-success" type="button" onclick="addManager()">Добавить</button>
                </div>
                <div class="settings-list" id="managersList">
                    <div class="text-muted text-center p-3">Загрузка...</div>
                </div>
            </div>
        </div>
    </div>

    <!-- Способы логистики -->
    <div class="col-md-6">
        <div class="card settings-card">
            <div class="card-header bg-secondary text-white">
                <h6 class="mb-0">🚚 Способы логистики</h6>
            </div>
            <div class="card-body">
                <div class="input-group mb-3">
                    <input type="text" class="form-control" id="newLogistics" placeholder="Введите способ логистики">
                    <button class="btn btn-success" type="button" onclick="addLogistics()">Добавить</button>
                </div>
                <div class="settings-list" id="logisticsTypesList">
                    <div class="text-muted text-center p-3">Загрузка...</div>
                </div>
            </div>
        </div>
    </div>

    <!-- Страны -->
    <div class="col-md-6">
        <div class="card settings-card">
            <div class="card-header bg-dark text-white">
                <h6 class="mb-0">🌍 Страны</h6>
            </div>
            <div class="card-body">
                <div class="input-group mb-3">
                    <input type="text" class="form-control" id="newCountry" placeholder="Введите название страны">
                    <button class="btn btn-success" type="button" onclick="addCountry()">Добавить</button>
                </div>
                <div class="settings-list" id="countriesList">
                    <div class="text-muted text-center p-3">Загрузка...</div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Функции для работы с настройками

function updateSettingsUI() {
    updateList('partnersList', partners, 'partners');
    updateList('banksList', banks, 'banks');
    updateList('legalEntitiesList', legalEntities, 'legal_entities');
    updateList('managersList', managers, 'managers');
    updateList('logisticsTypesList', logisticsTypes, 'logistics_types');
    updateList('countriesList', countries, 'countries');
}

function updateList(elementId, dataArray, table) {
    const container = document.getElementById(elementId);
    if (!container) return;

    if (dataArray.length === 0) {
        container.innerHTML = '<div class="text-muted text-center p-3">Нет данных</div>';
    } else {
        container.innerHTML = dataArray.map(item => `
            <div class="settings-item" id="item-${table}-${item.id}">
                <span class="item-name">${item.name}</span>
                <div class="item-actions">
                    <button class="btn btn-sm btn-outline-primary me-1" onclick="editItem('${table}', ${item.id}, '${item.name.replace(/'/g, "\\'")}')">
                        ✏️ Редактировать
                    </button>
                    <button class="btn btn-sm btn-outline-danger" onclick="removeItem('${table}', ${item.id})">
                        🗑️ Удалить
                    </button>
                </div>
            </div>
        `).join('');
    }
}

// Функции добавления
function addPartner() {
    addItem('partners', 'newPartner', 'add_partner');
}

function addBank() {
    addItem('banks', 'newBank', 'add_bank');
}

function addLegalEntity() {
    addItem('legal_entities', 'newLegalEntity', 'add_legal_entity');
}

function addManager() {
    addItem('managers', 'newManager', 'add_manager');
}

function addLogistics() {
    addItem('logistics_types', 'newLogistics', 'add_logistics');
}

function addCountry() {
    addItem('countries', 'newCountry', 'add_country');
}

// Общая функция добавления
function addItem(table, inputId, action) {
    const input = document.getElementById(inputId);
    const value = input.value.trim();
    
    if (!value) {
        alert('Введите значение!');
        return;
    }

    const formData = new FormData();
    formData.append('action', action);
    formData.append('name', value);

    fetch('api.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            input.value = '';
            loadAllData(); // Перезагружаем все данные
            showTempMessage('Элемент успешно добавлен!', 'success');
        } else {
            alert(data.error || 'Ошибка при добавлении');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Ошибка при добавлении: ' + error.message);
    });
}

// НОВАЯ ФУНКЦИЯ: Редактирование элемента
function editItem(table, id, currentName) {
    const newName = prompt('Введите новое название:', currentName);
    
    if (newName === null) return; // Пользователь отменил
    if (newName.trim() === '') {
        alert('Название не может быть пустым!');
        return;
    }
    if (newName === currentName) {
        alert('Название не изменилось!');
        return;
    }
    
    // Показываем загрузку
    const itemElement = document.getElementById(`item-${table}-${id}`);
    const originalContent = itemElement.innerHTML;
    itemElement.innerHTML = '<div class="text-center p-2"><div class="spinner-border spinner-border-sm"></div> Обновление...</div>';
    
    const formData = new FormData();
    formData.append('action', 'update_item');
    formData.append('table', table);
    formData.append('id', id);
    formData.append('name', newName.trim());

    fetch('api.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Обновляем интерфейс без перезагрузки всей страницы
            const itemElement = document.getElementById(`item-${table}-${id}`);
            const nameSpan = itemElement.querySelector('.item-name');
            if (nameSpan) {
                nameSpan.textContent = newName.trim();
            }
            // Восстанавливаем кнопки
            const actionsDiv = itemElement.querySelector('.item-actions');
            if (actionsDiv) {
                const editButton = actionsDiv.querySelector('button.btn-outline-primary');
                if (editButton) {
                    editButton.setAttribute('onclick', `editItem('${table}', ${id}, '${newName.replace(/'/g, "\\'")}')`);
                }
            }
            
            // Показываем уведомление об успехе
            showTempMessage('Элемент успешно обновлен!', 'success');
        } else {
            itemElement.innerHTML = originalContent;
            alert(data.error || 'Ошибка при обновлении');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        itemElement.innerHTML = originalContent;
        alert('Ошибка при обновлении: ' + error.message);
    });
}

// Функция удаления
function removeItem(table, id) {
    if (!confirm('Вы уверены, что хотите удалить этот элемент?')) return;

    const formData = new FormData();
    formData.append('action', 'remove_item');
    formData.append('table', table);
    formData.append('id', id);

    fetch('api.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            loadAllData();
            showTempMessage('Элемент успешно удален!', 'success');
        } else {
            alert(data.error || 'Ошибка при удалении');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Ошибка при удалении: ' + error.message);
    });
}

// Вспомогательная функция для показа временных сообщений
function showTempMessage(message, type = 'info') {
    const alertClass = type === 'success' ? 'alert-success' : 'alert-info';
    const messageDiv = document.createElement('div');
    messageDiv.className = `alert ${alertClass} alert-dismissible fade show`;
    messageDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    // Добавляем сообщение в начало страницы
    const firstCard = document.querySelector('.settings-card');
    if (firstCard) {
        firstCard.parentNode.insertBefore(messageDiv, firstCard);
    }
    
    // Автоматически скрываем через 3 секунды
    setTimeout(() => {
        if (messageDiv.parentNode) {
            messageDiv.remove();
        }
    }, 3000);
}

// Обработка Enter в полях ввода настроек
document.addEventListener('DOMContentLoaded', function() {
    const inputs = ['newPartner', 'newBank', 'newLegalEntity', 'newManager', 'newLogistics', 'newCountry'];
    inputs.forEach(inputId => {
        const input = document.getElementById(inputId);
        if (input) {
            input.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    const type = inputId.replace('new', '').toLowerCase();
                    if (type === 'partner') addPartner();
                    else if (type === 'bank') addBank();
                    else if (type === 'legalentity') addLegalEntity();
                    else if (type === 'manager') addManager();
                    else if (type === 'logistics') addLogistics();
                    else if (type === 'country') addCountry();
                }
            });
        }
    });
});
</script>