<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Статистика по партнерам</h1>
    <div>
        <button class="btn btn-success me-2" onclick="exportPartnerSummary()">
            📊 Выгрузить сводку в Excel
        </button>
        <button class="btn btn-outline-secondary" onclick="loadAllData()">
            🔄 Обновить
        </button>
    </div>
</div>

<!-- Фильтр по периоду -->
<div class="period-filter">
    <h5>Фильтр по периоду</h5>
    <div class="row">
        <div class="col-md-3">
            <div class="mb-3">
                <label class="form-label">Дата с</label>
                <input type="date" class="form-control" id="dateFrom">
            </div>
        </div>
        <div class="col-md-3">
            <div class="mb-3">
                <label class="form-label">Дата по</label>
                <input type="date" class="form-control" id="dateTo">
            </div>
        </div>
        <div class="col-md-3">
            <div class="mb-3">
                <label class="form-label">Быстрый выбор</label>
                <select class="form-select" id="quickPeriod" onchange="applyQuickPeriod()">
                    <option value="">Выберите период</option>
                    <option value="today">Сегодня</option>
                    <option value="yesterday">Вчера</option>
                    <option value="week">Текущая неделя</option>
                    <option value="month" selected>Текущий месяц</option>
                    <option value="quarter">Текущий квартал</option>
                    <option value="year">Текущий год</option>
                    <option value="lastMonth">Прошлый месяц</option>
                    <option value="lastQuarter">Прошлый квартал</option>
                    <option value="lastYear">Прошлый год</option>
                </select>
            </div>
        </div>
        <div class="col-md-3 d-flex align-items-end">
            <div class="mb-3 w-100">
                <button class="btn btn-primary w-100" onclick="applyDateFilter()">Применить фильтр</button>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="form-text">
                <span id="periodInfo">Показаны все данные</span>
                <button class="btn btn-sm btn-outline-secondary ms-2" onclick="clearDateFilter()">Очистить фильтр</button>
            </div>
        </div>
    </div>
</div>

<!-- НОВЫЙ БЛОК: Сводный отчет по партнерам -->
<div class="card mb-4">
    <div class="card-header bg-primary text-white">
        <h5 class="mb-0">📊 Сводный отчет по партнерам</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>Партнер</th>
                        <th>Общая сумма продаж</th>
                        <th>Количество сделок</th>
                        <th>Доля рынка</th>
                    </tr>
                </thead>
                <tbody id="partnerSummaryBody">
                    <tr><td colspan="4" class="text-center py-4">Загрузка данных...</td></tr>
                </tbody>
                <tfoot id="partnerSummaryFooter" style="display: none;">
                    <!-- Итоги будут здесь -->
                </tfoot>
            </table>
        </div>
    </div>
</div>

<div class="row mb-4">
    <div class="col-md-4">
        <div class="card bg-primary text-white">
            <div class="card-body">
                <h6>Всего партнеров</h6>
                <h3 id="totalPartnersCount">0</h3>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card bg-success text-white">
            <div class="card-body">
                <h6>Активных партнеров</h6>
                <h3 id="activePartnersCount">0</h3>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card bg-info text-white">
            <div class="card-body">
                <h6>Общая сумма продаж</h6>
                <h3 id="totalSalesAmount">0 ₽</h3>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h5 class="mb-0">Детальная статистика по партнерам</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>Партнер</th>
                        <th>Общая сумма продаж</th>
                        <th>Сумма информирования</th>
                        <th>Количество сделок</th>
                        <th>Средний чек</th>
                    </tr>
                </thead>
                <tbody id="partnerStatsBody">
                    <tr><td colspan="5" class="text-center py-4">Загрузка данных...</td></tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Детальная статистика по выбранному партнеру -->
<div class="card mt-4" id="partnerDetailCard" style="display: none;">
    <div class="card-header bg-light d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Детальная статистика по партнеру: <span id="selectedPartnerName" class="text-primary"></span></h5>
        <button class="btn btn-sm btn-outline-danger" onclick="hidePartnerDetail()">✕ Закрыть</button>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Дата</th>
                        <th>Клиент</th>
                        <th>Банк</th>
                        <th>Сумма договора</th>
                        <th>Сумма информирования</th>
                        <th>Страна</th>
                        <th>Менеджер</th>
                    </tr>
                </thead>
                <tbody id="partnerDetailTable">
                    <tr><td colspan="7" class="text-center py-4">Нет данных по сделкам этого партнера</td></tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Статистика по странам -->
<div class="card mt-4">
    <div class="card-header">
        <h5 class="mb-0">Статистика продаж по странам</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Страна</th>
                        <th>Общая сумма продаж</th>
                        <th>Сумма информирования</th>
                        <th>Количество сделок</th>
                        <th>Средний чек</th>
                        <th>Доля от общего объема</th>
                    </tr>
                </thead>
                <tbody id="countryStatsTable">
                    <tr><td colspan="6" class="text-center py-4">Загрузка данных...</td></tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
// Простая и надежная инициализация обработчиков
document.addEventListener('DOMContentLoaded', function() {
    // Инициализация при загрузке страницы
    setTimeout(initPartnerStats, 100);
});

function initPartnerStats() {
    const tbody = document.getElementById('partnerStatsBody');
    if (tbody) {
        tbody.addEventListener('click', function(e) {
            const row = e.target.closest('.partner-row');
            if (row) {
                const partnerName = row.getAttribute('data-partner');
                if (partnerName) {
                    showPartnerDetail(partnerName);
                }
            }
        });
    }
}
</script>