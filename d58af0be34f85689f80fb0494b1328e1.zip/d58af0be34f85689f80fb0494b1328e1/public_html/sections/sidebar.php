<nav class="col-md-3 col-lg-2 d-md-block sidebar">
    <div class="position-sticky pt-3">
        <h4 class="text-center mb-4" style="color: white; font-weight: 700;">💰 Учет продаж Ульяновск</h4>
        
        <!-- Информация о пользователе -->
        <div class="user-info">
            <div><strong><?php echo $current_user['full_name']; ?></strong></div>
            <small>
                <?php 
                $role_names = [
                    'admin' => '👑 Администратор',
                    'manager' => '👨‍💼 Менеджер', 
                    'logistics' => '🚚 Логист'
                ];
                echo $role_names[$current_user['role']];
                ?>
            </small>
            <br>
            <a href="logout.php" class="btn btn-sm btn-outline-light mt-2" style="border-color: rgba(255,255,255,0.3);">
                🚪 Выйти
            </a>
        </div>

        <ul class="nav flex-column mt-3">
            <li class="nav-item">
                <a href="#dashboard" class="nav-link active" onclick="showSection('dashboard')">
                    📊 Дашборд
                </a>
            </li>
            <li class="nav-item">
                <a href="#deals" class="nav-link" onclick="showSection('deals')">
                    📋 Все сделки
                </a>
            </li>
            <li class="nav-item" id="addDealLink">
                <a href="#add-deal" class="nav-link" onclick="showSection('add-deal'); resetDealForm();">
                    ➕ Новая сделка
                </a>
            </li>
            
            <!-- Аналитика продаж (ТОЛЬКО ДЛЯ АДМИНОВ) -->
            <?php if ($current_user['role'] === 'admin'): ?>
            <li class="nav-item" id="analyticsLink">
                <a href="#analytics" class="nav-link" onclick="showSection('analytics')">
                    📈 Аналитика
                </a>
            </li>
            <?php endif; ?>
            
            <!-- Статистика по партнерам (ТОЛЬКО ДЛЯ АДМИНОВ) -->
            <?php if ($current_user['role'] === 'admin'): ?>
            <li class="nav-item" id="partnerStatsLink">
                <a href="#partner-stats" class="nav-link" onclick="showSection('partner-stats')">
                    📊 Статистика
                </a>
            </li>
            <?php endif; ?>
            
            <li class="nav-item">
                <a href="#logistics" class="nav-link" onclick="showSection('logistics')">
                    🚚 Логистика
                </a>
            </li>
            
            <!-- Управление партнерами (только для админов) -->
            <?php if ($current_user['role'] === 'admin'): ?>
            <li class="nav-item">
                <a href="#partners" class="nav-link" onclick="showSection('partners')">
                    🏢 Партнеры
                </a>
            </li>
            <?php endif; ?>
            
            <!-- Управление пользователями (только для админов) -->
            <?php if ($current_user['role'] === 'admin'): ?>
            <li class="nav-item">
                <a href="#user-management" class="nav-link" onclick="showSection('user-management')">
                    👥 Пользователи
                </a>
            </li>
            <?php endif; ?>
            
            <!-- Настройки (ТОЛЬКО ДЛЯ АДМИНОВ) -->
            <?php if ($current_user['role'] === 'admin'): ?>
            <li class="nav-item" id="settingsLink">
                <a href="#settings" class="nav-link" onclick="showSection('settings')">
                    ⚙️ Настройки
                </a>
            </li>
            <?php endif; ?>
        </ul>
    </div>
</nav>