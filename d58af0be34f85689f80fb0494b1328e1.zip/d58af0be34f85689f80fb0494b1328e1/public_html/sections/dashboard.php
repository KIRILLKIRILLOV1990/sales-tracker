<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Расчет заработных плат менеджеров</h1>
    <button class="btn btn-outline-secondary" onclick="loadSalaryData(); loadLogisticsStats();">
        🔄 Обновить
    </button>
</div>

<!-- НОВЫЙ БЛОК: Статус логистики -->
<div class="row mb-4" id="logisticsStatusWidget" style="display: none;">
    <div class="col-12">
        <div class="card border-warning">
            <div class="card-header bg-warning text-dark d-flex justify-content-between align-items-center">
                <h6 class="mb-0">🚚 Внимание: сделки ожидают документы</h6>
                <button class="btn btn-sm btn-outline-dark" onclick="showSection('logistics')">
                    Перейти к логистике →
                </button>
            </div>
            <div class="card-body">
                <div class="row text-center">
                    <div class="col-md-6">
                        <div class="stat-card bg-light">
                            <h6>Сделок ожидают документы</h6>
                            <h3 class="text-warning" id="pendingDealsCount">0</h3>
                            <small>Требуют вашего внимания</small>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="stat-card bg-light">
                            <h6 id="userPendingTitle">Ваши ожидающие сделки</h6>
                            <h3 class="text-warning" id="userPendingDealsCount">0</h3>
                            <small id="userPendingText">Ваши сделки</small>
                        </div>
                    </div>
                </div>
                <div class="mt-3">
                    <button class="btn btn-warning btn-sm" onclick="showSection('logistics')">
                        📋 Просмотреть все ожидающие сделки
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Фильтр по периоду для зарплат -->
<div class="period-filter">
    <h5>Период расчета</h5>
    <div class="row">
        <div class="col-md-3">
            <div class="mb-3">
                <label class="form-label">Дата с</label>
                <input type="date" class="form-control" id="salaryDateFrom">
            </div>
        </div>
        <div class="col-md-3">
            <div class="mb-3">
                <label class="form-label">Дата по</label>
                <input type="date" class="form-control" id="salaryDateTo">
            </div>
        </div>
        <div class="col-md-3">
            <div class="mb-3">
                <label class="form-label">Быстрый выбор</label>
                <select class="form-select" id="salaryQuickPeriod" onchange="applySalaryQuickPeriod()">
                    <option value="currentWeek" selected>Текущая неделя</option>
                    <option value="currentMonth">Текущий месяц</option>
                    <option value="lastWeek">Прошлая неделя</option>
                    <option value="lastMonth">Прошлый месяц</option>
                </select>
            </div>
        </div>
        <div class="col-md-3 d-flex align-items-end">
            <div class="mb-3 w-100">
                <button class="btn btn-primary w-100" onclick="applySalaryDateFilter()">Применить период</button>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="form-text">
                <span id="salaryPeriodInfo">Показана зарплата за текущую неделю</span>
                <button class="btn btn-sm btn-outline-secondary ms-2" onclick="clearSalaryDateFilter()">Сбросить</button>
            </div>
        </div>
    </div>
</div>

<div id="salaryDashboardContent">
    <div class="text-center py-5">
        <div class="spinner-border text-primary" role="status">
            <span class="visually-hidden">Загрузка...</span>
        </div>
        <p class="mt-2">Загрузка данных о зарплатах...</p>
    </div>
</div>