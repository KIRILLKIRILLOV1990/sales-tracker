<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">📊 Аналитика продаж</h1>
    <div>
        <button class="btn btn-success me-2" onclick="exportAnalytics()">
            📈 Выгрузить аналитику
        </button>
        <button class="btn btn-outline-secondary" onclick="loadAnalyticsData()">
            🔄 Обновить
        </button>
    </div>
</div>

<!-- Фильтр по периоду -->
<div class="period-filter">
    <h5>Период анализа</h5>
    <div class="row">
        <div class="col-md-3">
            <div class="mb-3">
                <label class="form-label">Начало периода</label>
                <input type="month" class="form-control" id="analyticsStartMonth">
            </div>
        </div>
        <div class="col-md-3">
            <div class="mb-3">
                <label class="form-label">Конец периода</label>
                <input type="month" class="form-control" id="analyticsEndMonth">
            </div>
        </div>
        <div class="col-md-3">
            <div class="mb-3">
                <label class="form-label">Фильтр по динамике</label>
                <select class="form-select" id="dynamicsFilter" onchange="applyDynamicsFilter()">
                    <option value="all">📊 Все партнеры</option>
                    <option value="growth">↗️ Только рост</option>
                    <option value="decline">↘️ Только спад</option>
                    <option value="high-growth">🚀 Высокий рост (+20%+)</option>
                    <option value="high-decline">⚠️ Сильное падение (-20%+)</option>
                </select>
            </div>
        </div>
        <div class="col-md-3 d-flex align-items-end">
            <div class="mb-3 w-100">
                <button class="btn btn-primary w-100" onclick="loadAnalyticsData()">Применить</button>
            </div>
        </div>
    </div>
</div>

<!-- Статистика -->
<div class="row mb-4">
    <div class="col-md-3">
        <div class="card bg-primary text-white">
            <div class="card-body text-center">
                <h6>Общий рост</h6>
                <h3 id="totalGrowth">0%</h3>
                <small>За период</small>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-success text-white">
            <div class="card-body text-center">
                <h6>Растущих партнеров</h6>
                <h3 id="growingPartners">0</h3>
                <small>Увеличили продажи</small>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-warning text-white">
            <div class="card-body text-center">
                <h6>Падающих партнеров</h6>
                <h3 id="decliningPartners">0</h3>
                <small>Снизили продажи</small>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-info text-white">
            <div class="card-body text-center">
                <h6>Активных партнеров</h6>
                <h3 id="activePartners">0</h3>
                <small>Всего в периоде</small>
            </div>
        </div>
    </div>
</div>

<!-- Основная таблица -->
<div class="card mb-4">
    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
        <h5 class="mb-0">📈 Динамика продаж по партнерам</h5>
        <div class="text-white small">
            Показано: <span id="shownPartnersCount">0</span> из <span id="totalPartnersCount">0</span> партнеров
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>Партнер</th>
                        <th id="month1Header">Месяц 1</th>
                        <th id="month2Header">Месяц 2</th>
                        <th id="month3Header">Месяц 3</th>
                        <th id="month4Header">Месяц 4</th>
                        <th id="month5Header">Месяц 5</th>
                        <th id="month6Header">Месяц 6</th>
                        <th>Динамика</th>
                        <th>Тренд</th>
                    </tr>
                </thead>
                <tbody id="analyticsTableBody">
                    <tr><td colspan="9" class="text-center py-4">Загрузка данных...</td></tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Топы -->
<div class="row">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header bg-success text-white">
                <h5 class="mb-0">🏆 Топ-5 растущих партнеров</h5>
            </div>
            <div class="card-body">
                <div id="topGrowingPartners">
                    <div class="text-center py-4">Загрузка...</div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-6">
        <div class="card">
            <div class="card-header bg-warning text-white">
                <h5 class="mb-0">⚠️ Партнеры с падением продаж</h5>
            </div>
            <div class="card-body">
                <div id="decliningPartnersList">
                    <div class="text-center py-4">Загрузка...</div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Глобальные переменные
let analyticsData = [];
let filteredAnalyticsData = [];
let currentPeriod = {};

// Инициализация
document.addEventListener('DOMContentLoaded', function() {
    console.log('Analytics page loaded');
    initializeAnalyticsFilters();
    loadAnalyticsData();
});

function initializeAnalyticsFilters() {
    // Устанавливаем последние 6 месяцев по умолчанию
    const endDate = new Date();
    const startDate = new Date();
    startDate.setMonth(endDate.getMonth() - 5);
    startDate.setDate(1);
    
    document.getElementById('analyticsStartMonth').value = startDate.toISOString().slice(0, 7);
    document.getElementById('analyticsEndMonth').value = endDate.toISOString().slice(0, 7);
    document.getElementById('dynamicsFilter').value = 'all';
}

function loadAnalyticsData() {
    const startMonth = document.getElementById('analyticsStartMonth').value;
    const endMonth = document.getElementById('analyticsEndMonth').value;
    
    if (!startMonth || !endMonth) {
        alert('Выберите период для анализа');
        return;
    }
    
    // Сохраняем текущий период для экспорта
    currentPeriod = { start: startMonth, end: endMonth };
    
    // Показываем загрузку
    showLoading();
    
    // Загружаем данные из API
    fetch(`api.php?action=get_analytics&start_month=${startMonth}&end_month=${endMonth}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                analyticsData = data.data;
                currentPeriod.months = data.period.months;
                updateMonthHeaders(data.period.months);
                applyDynamicsFilter();
            } else {
                throw new Error(data.error || 'Ошибка загрузки данных');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showError('Ошибка загрузки: ' + error.message);
        });
}

function updateMonthHeaders(months) {
    const monthNames = ['Янв', 'Фев', 'Мар', 'Апр', 'Май', 'Июн', 'Июл', 'Авг', 'Сен', 'Окт', 'Ноя', 'Дек'];
    
    months.forEach((month, index) => {
        const monthElement = document.getElementById(`month${index + 1}Header`);
        if (monthElement) {
            const date = new Date(month + '-01');
            monthElement.textContent = `${monthNames[date.getMonth()]} ${date.getFullYear()}`;
        }
    });
}

function applyDynamicsFilter() {
    const filter = document.getElementById('dynamicsFilter').value;
    
    if (!analyticsData.length) return;
    
    switch(filter) {
        case 'all':
            filteredAnalyticsData = [...analyticsData];
            break;
        case 'growth':
            filteredAnalyticsData = analyticsData.filter(item => item.growth > 0);
            break;
        case 'decline':
            filteredAnalyticsData = analyticsData.filter(item => item.growth < 0);
            break;
        case 'high-growth':
            filteredAnalyticsData = analyticsData.filter(item => item.growth >= 20);
            break;
        case 'high-decline':
            filteredAnalyticsData = analyticsData.filter(item => item.growth <= -20);
            break;
        default:
            filteredAnalyticsData = [...analyticsData];
    }
    
    updateAnalyticsUI();
}

function updateAnalyticsUI() {
    updateMainTable();
    updateStatistics();
    updateTopLists();
}

function updateMainTable() {
    const tbody = document.getElementById('analyticsTableBody');
    
    if (filteredAnalyticsData.length === 0) {
        tbody.innerHTML = '<tr><td colspan="9" class="text-center py-4">Нет данных по выбранному фильтру</td></tr>';
        return;
    }
    
    tbody.innerHTML = filteredAnalyticsData.map(item => {
        const monthlyCells = item.monthlyData.map(amount => 
            `<td>${amount.toLocaleString('ru-RU')} ₽</td>`
        ).join('');
        
        const growthColor = item.growth >= 0 ? 'text-success' : 'text-danger';
        const trendIcon = item.growth >= 0 ? '↗️' : '↘️';
        const growthDisplay = item.growth >= 0 ? `+${item.growth.toFixed(1)}%` : `${item.growth.toFixed(1)}%`;
        
        return `
            <tr>
                <td><strong>${item.partner}</strong></td>
                ${monthlyCells}
                <td class="${growthColor}"><strong>${growthDisplay}</strong></td>
                <td>${trendIcon}</td>
            </tr>
        `;
    }).join('');
    
    document.getElementById('shownPartnersCount').textContent = filteredAnalyticsData.length;
    document.getElementById('totalPartnersCount').textContent = analyticsData.length;
}

function updateStatistics() {
    const growing = analyticsData.filter(item => item.growth > 0).length;
    const declining = analyticsData.filter(item => item.growth < 0).length;
    const totalGrowth = analyticsData.length > 0 ? 
        analyticsData.reduce((sum, item) => sum + item.growth, 0) / analyticsData.length : 0;
    
    document.getElementById('totalGrowth').textContent = `${totalGrowth >= 0 ? '+' : ''}${totalGrowth.toFixed(1)}%`;
    document.getElementById('growingPartners').textContent = growing;
    document.getElementById('decliningPartners').textContent = declining;
    document.getElementById('activePartners').textContent = analyticsData.length;
}

function updateTopLists() {
    const topGrowing = [...analyticsData]
        .filter(item => item.growth > 0)
        .sort((a, b) => b.growth - a.growth)
        .slice(0, 5);
    
    const topDeclining = [...analyticsData]
        .filter(item => item.growth < 0)
        .sort((a, b) => a.growth - b.growth)
        .slice(0, 5);
    
    document.getElementById('topGrowingPartners').innerHTML = topGrowing.length > 0 ? 
        topGrowing.map(item => `
            <div class="d-flex justify-content-between align-items-center mb-2 p-2 border rounded">
                <span>${item.partner}</span>
                <span class="text-success"><strong>+${item.growth.toFixed(1)}%</strong></span>
            </div>
        `).join('') : '<div class="text-center text-muted">Нет данных</div>';
    
    document.getElementById('decliningPartnersList').innerHTML = topDeclining.length > 0 ? 
        topDeclining.map(item => `
            <div class="d-flex justify-content-between align-items-center mb-2 p-2 border rounded">
                <span>${item.partner}</span>
                <span class="text-danger"><strong>${item.growth.toFixed(1)}%</strong></span>
            </div>
        `).join('') : '<div class="text-center text-muted">Нет данных</div>';
}

function showLoading() {
    document.getElementById('analyticsTableBody').innerHTML = 
        '<tr><td colspan="9" class="text-center py-4"><div class="spinner-border"></div><p class="mt-2">Загрузка...</p></td></tr>';
}

function showError(message) {
    document.getElementById('analyticsTableBody').innerHTML = 
        `<tr><td colspan="9" class="text-center py-4 text-danger">${message}</td></tr>`;
}

// РАБОЧАЯ ФУНКЦИЯ ЭКСПОРТА
function exportAnalytics() {
    if (filteredAnalyticsData.length === 0) {
        alert('Нет данных для экспорта');
        return;
    }
    
    // Формируем CSV с правильной кодировкой
    let csv = "Партнер;";
    
    // Добавляем заголовки месяцев
    if (currentPeriod.months && currentPeriod.months.length > 0) {
        const monthNames = ['Янв', 'Фев', 'Мар', 'Апр', 'Май', 'Июн', 'Июл', 'Авг', 'Сен', 'Окт', 'Ноя', 'Дек'];
        currentPeriod.months.forEach(month => {
            const date = new Date(month + '-01');
            csv += `${monthNames[date.getMonth()]} ${date.getFullYear()};`;
        });
    } else {
        // Заглушка если нет данных о месяцах
        csv += "Месяц 1;Месяц 2;Месяц 3;Месяц 4;Месяц 5;Месяц 6;";
    }
    
    csv += "Динамика %;Тренд\n";
    
    // Добавляем данные партнеров
    filteredAnalyticsData.forEach(item => {
        const monthlyData = item.monthlyData.map(amount => amount.toLocaleString('ru-RU')).join(';');
        const trend = item.growth >= 0 ? 'Рост' : 'Спад';
        const growthDisplay = item.growth >= 0 ? `+${item.growth.toFixed(1)}%` : `${item.growth.toFixed(1)}%`;
        csv += `${item.partner};${monthlyData};${growthDisplay};${trend}\n`;
    });
    
    // Создаем и скачиваем файл
    const blob = new Blob(["\uFEFF" + csv], { 
        type: 'text/csv;charset=utf-8;' 
    });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    
    // Формируем имя файла
    const startMonth = document.getElementById('analyticsStartMonth').value;
    const endMonth = document.getElementById('analyticsEndMonth').value;
    const filterType = document.getElementById('dynamicsFilter').value;
    
    let filename = `аналитика_продаж_${startMonth}_по_${endMonth}`;
    
    // Добавляем тип фильтра в имя файла
    const filterNames = {
        'all': 'все_партнеры',
        'growth': 'только_рост', 
        'decline': 'только_спад',
        'high-growth': 'высокий_рост',
        'high-decline': 'сильное_падение'
    };
    
    if (filterNames[filterType]) {
        filename += `_${filterNames[filterType]}`;
    }
    
    filename += '.csv';
    
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.style.display = 'none';
    
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    console.log('Экспорт завершен: ' + filename);
}
</script>