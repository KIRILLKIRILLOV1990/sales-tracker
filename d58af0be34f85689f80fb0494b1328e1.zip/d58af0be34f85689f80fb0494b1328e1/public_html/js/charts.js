function updateDashboard() {
    const filteredDeals = filterDealsByDate(deals, dateFilter);
    
    const totalAmount = filteredDeals.reduce((sum, deal) => sum + parseFloat(deal.contract_amount || 0), 0);
    const dealsCount = filteredDeals.length;
    const activePartners = [...new Set(filteredDeals.map(deal => deal.partner))].length;
    const pendingDelivery = filteredDeals.filter(deal => deal.status === 'pending').length;

    document.getElementById('totalAmount').textContent = totalAmount.toLocaleString() + ' ₽';
    document.getElementById('dealsCount').textContent = dealsCount;
    document.getElementById('activePartners').textContent = activePartners;
    document.getElementById('totalPartners').textContent = partners.length;
    document.getElementById('pendingDelivery').textContent = pendingDelivery;

    updateManagersChart(filteredDeals);
}

function updateManagersChart(filteredDeals) {
    const ctx = document.getElementById('managersChart');
    if (!ctx) return;

    if (window.managersChartInstance) {
        window.managersChartInstance.destroy();
    }

    const managerSales = {};
    filteredDeals.forEach(deal => {
        if (managerSales[deal.manager]) {
            managerSales[deal.manager] += parseFloat(deal.contract_amount || 0);
        } else {
            managerSales[deal.manager] = parseFloat(deal.contract_amount || 0);
        }
    });

    if (Object.keys(managerSales).length === 0) {
        ctx.closest('.card-body').innerHTML = '<p class="text-muted text-center py-4">Нет данных для отображения</p>';
        return;
    }

    window.managersChartInstance = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: Object.keys(managerSales),
            datasets: [{
                label: 'Продажи (₽)',
                data: Object.values(managerSales),
                backgroundColor: '#4CAF50'
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: false
                }
            }
        }
    });
}