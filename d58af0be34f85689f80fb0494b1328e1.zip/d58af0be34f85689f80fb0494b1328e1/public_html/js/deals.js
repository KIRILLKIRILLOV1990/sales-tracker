// Функции для работы со сделками

function resetDealForm() {
    document.getElementById('dealForm').reset();
    document.getElementById('dealId').value = '';
    document.getElementById('dealFormTitle').textContent = 'Добавить успешную сделку';
    document.getElementById('authDate').valueAsDate = new Date();
    toggleTrackNumber();
}

function editDeal(dealId) {
    showLoading(true);
    
    fetch(`api.php?action=get_deal&dealId=${dealId}`)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            if (data.error) {
                throw new Error(data.error);
            }
            
            if (data.success) {
                const deal = data.deal;
                
                // Заполняем форму данными
                document.getElementById('dealId').value = deal.id;
                document.getElementById('dealPartner').value = deal.partner;
                document.getElementById('dealLegalEntity').value = deal.legal_entity;
                document.getElementById('clientName').value = deal.client_name;
                document.getElementById('dealCountry').value = deal.country;
                document.getElementById('authDate').value = deal.auth_date;
                document.getElementById('dealBank').value = deal.bank;
                document.getElementById('interestRate').value = deal.interest_rate;
                document.getElementById('installmentPeriod').value = deal.installment_period;
                document.getElementById('contractNumber').value = deal.contract_number;
                document.getElementById('contractAmount').value = deal.contract_amount;
                document.getElementById('infoAmount').value = deal.info_amount;
                document.getElementById('noInfoAmount').value = deal.no_info_amount;
                document.getElementById('dealLogistics').value = deal.logistics;
                document.getElementById('trackNumber').value = deal.track_number || '';
                document.getElementById('dealManager').value = deal.manager;
                document.getElementById('currencyAmount').value = deal.currency_amount || '';
                document.getElementById('clientEmail').value = deal.client_email || '';
                document.getElementById('clientPhone').value = deal.client_phone || '';
                
                // Обновляем UI
                document.getElementById('dealFormTitle').textContent = 'Редактировать сделку';
                toggleTrackNumber();
                
                // Показываем форму
                showSection('add-deal');
            } else {
                alert('Ошибка загрузки сделки: ' + data.error);
            }
            showLoading(false);
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Ошибка загрузки сделки: ' + error.message);
            showLoading(false);
        });
}

function deleteDeal(dealId, clientName) {
    if (!confirm(`Вы уверены, что хотите удалить сделку с клиентом "${clientName}"?`)) {
        return;
    }
    
    const formData = new FormData();
    formData.append('action', 'delete_deal');
    formData.append('dealId', dealId);

    fetch('api.php', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.json();
    })
    .then(data => {
        if (data.error) {
            throw new Error(data.error);
        }
        
        if (data.success) {
            alert('Сделка успешно удалена!');
            loadAllData();
            loadLogisticsStats(); // ОБНОВЛЯЕМ СТАТИСТИКУ ЛОГИСТИКИ
        } else {
            alert('Ошибка при удалении: ' + data.error);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Ошибка при удалении: ' + error.message);
    });
}

function updateDealForm() {
    updateSelect('dealPartner', partners);
    updateSelect('dealBank', banks);
    updateSelect('dealLegalEntity', legalEntities);
    updateSelect('dealManager', managers);
    updateSelect('dealLogistics', logisticsTypes);
    updateSelect('dealCountry', countries);
}

function updateSelect(selectId, dataArray) {
    const select = document.getElementById(selectId);
    if (!select) return;
    
    const currentValue = select.value;
    
    select.innerHTML = `<option value="">Выберите...</option>`;
    dataArray.forEach(item => {
        const option = document.createElement('option');
        option.value = item.name;
        option.textContent = item.name;
        select.appendChild(option);
    });
    
    if (dataArray.some(item => item.name === currentValue)) {
        select.value = currentValue;
    }
}

function toggleTrackNumber() {
    const logisticsType = document.getElementById('dealLogistics').value;
    const trackSection = document.getElementById('trackNumberSection');
    
    if (logisticsType === 'Почта') {
        trackSection.style.display = 'block';
    } else {
        trackSection.style.display = 'none';
        document.getElementById('trackNumber').value = '';
    }
}

function saveDeal() {
    const dealId = document.getElementById('dealId').value;
    const isEditing = dealId !== '';
    
    const formData = new FormData();
    formData.append('action', isEditing ? 'update_deal' : 'save_deal');
    
    if (isEditing) {
        formData.append('dealId', dealId);
    }
    
    formData.append('partner', document.getElementById('dealPartner').value);
    formData.append('legalEntity', document.getElementById('dealLegalEntity').value);
    formData.append('clientName', document.getElementById('clientName').value);
    formData.append('country', document.getElementById('dealCountry').value);
    formData.append('authDate', document.getElementById('authDate').value);
    formData.append('bank', document.getElementById('dealBank').value);
    formData.append('interestRate', document.getElementById('interestRate').value);
    formData.append('installmentPeriod', document.getElementById('installmentPeriod').value);
    formData.append('contractNumber', document.getElementById('contractNumber').value);
    formData.append('contractAmount', document.getElementById('contractAmount').value);
    formData.append('infoAmount', document.getElementById('infoAmount').value);
    formData.append('noInfoAmount', document.getElementById('noInfoAmount').value);
    formData.append('logistics', document.getElementById('dealLogistics').value);
    formData.append('trackNumber', document.getElementById('trackNumber').value);
    formData.append('manager', document.getElementById('dealManager').value);
    formData.append('currencyAmount', document.getElementById('currencyAmount').value);
    formData.append('clientEmail', document.getElementById('clientEmail').value);
    formData.append('clientPhone', document.getElementById('clientPhone').value);

    fetch('api.php', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.json();
    })
    .then(data => {
        if (data.error) {
            throw new Error(data.error);
        }
        
        if (data.success) {
            alert(isEditing ? 'Сделка успешно обновлена!' : 'Сделка успешно сохранена!');
            resetDealForm();
            loadAllData();
            loadLogisticsStats(); // ОБНОВЛЯЕМ СТАТИСТИКУ ЛОГИСТИКИ
            showSection('deals');
        } else {
            alert('Ошибка при сохранении: ' + data.error);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Ошибка при сохранении сделки: ' + error.message);
    });
}

function markAsDelivered(dealId) {
    // Проверяем права
    if (currentUserRole !== 'admin' && currentUserRole !== 'logistics') {
        alert('Только администратор или логист может менять статусы доставки');
        return;
    }

    const formData = new FormData();
    formData.append('action', 'update_deal_status');
    formData.append('dealId', dealId);
    formData.append('status', 'completed');

    fetch('api.php', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.json();
    })
    .then(data => {
        if (data.error) {
            throw new Error(data.error);
        }
        
        if (data.success) {
            loadAllData();
            loadLogisticsStats(); // ОБНОВЛЯЕМ СТАТИСТИКУ ЛОГИСТИКИ
            alert('Доставка отмечена как выполненная!');
        } else {
            alert('Ошибка при обновлении статуса');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Ошибка при обновлении статуса: ' + error.message);
    });
}

// ПРОСТАЯ И РАБОЧАЯ ФУНКЦИЯ ВЫГРУЗКИ В EXCEL
function exportToExcel() {
    showLoading(true);
    
    try {
        // Получаем параметры фильтра
        const dateFrom = document.getElementById('dealsDateFrom').value;
        const dateTo = document.getElementById('dealsDateTo').value;
        
        // Формируем URL с параметрами
        let url = 'full_export.php';
        let params = [];
        
        if (dateFrom) params.push('dateFrom=' + encodeURIComponent(dateFrom));
        if (dateTo) params.push('dateTo=' + encodeURIComponent(dateTo));
        
        if (params.length > 0) {
            url += '?' + params.join('&');
        }
        
        // Создаем скрытую ссылку и кликаем по ней
        const link = document.createElement('a');
        link.href = url;
        link.download = 'deals_export.csv';
        link.style.display = 'none';
        
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        showLoading(false);
        
    } catch (error) {
        console.error('Export error:', error);
        alert('Ошибка при выгрузке: ' + error.message);
        showLoading(false);
    }
}

// Вспомогательная функция для фильтрации сделок по дате
function filterDealsByDate(dealsArray, filter) {
    if (!filter.from && !filter.to) {
        return dealsArray;
    }
    
    return dealsArray.filter(deal => {
        const dealDate = new Date(deal.auth_date);
        const fromDate = filter.from ? new Date(filter.from) : null;
        const toDate = filter.to ? new Date(filter.to) : null;
        
        let valid = true;
        if (fromDate) {
            valid = valid && dealDate >= fromDate;
        }
        if (toDate) {
            const toDatePlusOne = new Date(toDate);
            toDatePlusOne.setDate(toDatePlusOne.getDate() + 1);
            valid = valid && dealDate < toDatePlusOne;
        }
        
        return valid;
    });
}