// tables.js - полная версия с обновленной функцией updateLogisticsTable

// Функции для работы с таблицами

function updateDealsTable() {
    const tbody = document.getElementById('dealsTable');
    if (!tbody) return;

    const filteredDeals = filterDealsByDate(deals, dealsDateFilter);

    if (filteredDeals.length === 0) {
        tbody.innerHTML = '<tr><td colspan="17" class="text-center py-4">Нет данных о сделках за выбранный период</td></tr>';
    } else {
        tbody.innerHTML = filteredDeals.map((deal, index) => `
            <tr>
                <td><span class="deal-number">${deal.id}</span></td>
                <td>${formatDate(deal.auth_date)}</td>
                <td>${deal.partner}</td>
                <td>${deal.client_name}</td>
                <td>${deal.bank}</td>
                <td>${parseFloat(deal.contract_amount).toLocaleString()} ₽</td>
                <td>${parseFloat(deal.info_amount).toLocaleString()} ₽</td>
                <td>${parseFloat(deal.no_info_amount).toLocaleString()} ₽</td>
                <td>${deal.interest_rate}%</td>
                <td>${deal.installment_period} мес.</td>
                <td>${deal.contract_number}</td>
                <td>${deal.country}</td>
                <td>${deal.client_email || '-'}</td>
                <td>${deal.client_phone || '-'}</td>
                <td>${deal.manager}</td>
                <td><span class="logistics-status ${deal.status === 'completed' ? 'status-completed' : 'status-pending'}">${deal.status === 'completed' ? 'Завершено' : 'В процессе'}</span></td>
                <td>
                    <div class="btn-group btn-group-sm" role="group">
                        ${currentUserRole === 'admin' || currentUserRole === 'manager' ? 
                            `<button class="btn btn-outline-primary" onclick="editDeal(${deal.id})" title="Редактировать">
                                ✏️
                            </button>` : ''
                        }
                        ${currentUserRole === 'admin' ? 
                            `<button class="btn btn-outline-danger" onclick="deleteDeal(${deal.id}, '${deal.client_name.replace(/'/g, "\\'")}')" title="Удалить">
                                🗑️
                            </button>` : ''
                        }
                    </div>
                </td>
            </tr>
        `).join('');
    }
}

// ОБНОВЛЕННАЯ ФУНКЦИЯ: Теперь включает столбец "Банк" и "Менеджер"
function updateLogisticsTable() {
    const tbody = document.getElementById('logisticsTable');
    if (!tbody) return;

    const filteredDeals = filterDealsByDate(deals, dateFilter);
    const pendingDeals = filteredDeals.filter(deal => deal.status === 'pending');
    
    if (pendingDeals.length === 0) {
        tbody.innerHTML = '<tr><td colspan="9" class="text-center py-4">Нет сделок, ожидающих доставки</td></tr>';
    } else {
        tbody.innerHTML = pendingDeals.map(deal => `
            <tr>
                <td>${formatDate(deal.auth_date)}</td>
                <td><strong>${deal.client_name}</strong></td>
                <td>${deal.partner}</td>
                <td><span class="badge bg-info">${deal.bank}</span></td>
                <td>${deal.logistics}</td>
                <td>${deal.track_number ? `<code>${deal.track_number}</code>` : '<span class="text-muted">Не указан</span>'}</td>
                <td><span class="badge bg-primary">${deal.manager}</span></td>
                <td><span class="badge bg-warning">Ожидает доставки</span></td>
                <td>
                    ${currentUserRole === 'admin' || currentUserRole === 'logistics' ? 
                        `<button class="btn btn-sm btn-success" onclick="markAsDelivered(${deal.id})">✅ Доставлено</button>` :
                        `<span class="text-muted">Только для логиста</span>`
                    }
                </td>
            </tr>
        `).join('');
    }
}

// НОВАЯ ФУНКЦИЯ: Обновление сводного отчета по партнерам
function updatePartnerSummary() {
    console.log('Обновление сводного отчета по партнерам...');
    
    const filteredDeals = filterDealsByDate(deals, dateFilter);
    
    // Считаем статистику по партнерам
    const partnerStats = {};
    let totalSalesAll = 0;
    let totalDealsAll = 0;
    
    filteredDeals.forEach(deal => {
        if (!partnerStats[deal.partner]) {
            partnerStats[deal.partner] = {
                totalSales: 0,
                dealCount: 0
            };
        }
        
        partnerStats[deal.partner].totalSales += parseFloat(deal.contract_amount || 0);
        partnerStats[deal.partner].dealCount += 1;
        
        totalSalesAll += parseFloat(deal.contract_amount || 0);
        totalDealsAll += 1;
    });

    const tbody = document.getElementById('partnerSummaryBody');
    const tfoot = document.getElementById('partnerSummaryFooter');
    
    if (!tbody) {
        console.error('Не найден элемент partnerSummaryBody');
        return;
    }

    if (Object.keys(partnerStats).length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" class="text-center py-4">Нет данных для отображения</td></tr>';
        tfoot.style.display = 'none';
    } else {
        // Сортируем партнеров по убыванию суммы продаж
        const sortedPartners = Object.keys(partnerStats).sort((a, b) => 
            partnerStats[b].totalSales - partnerStats[a].totalSales
        );
        
        tbody.innerHTML = sortedPartners.map(partner => {
            const stats = partnerStats[partner];
            const marketShare = totalSalesAll > 0 ? ((stats.totalSales / totalSalesAll) * 100).toFixed(1) : 0;
            
            return `
                <tr>
                    <td><strong>${partner}</strong></td>
                    <td>${stats.totalSales.toLocaleString()} ₽</td>
                    <td>${stats.dealCount}</td>
                    <td>${marketShare}%</td>
                </tr>
            `;
        }).join('');
        
        // Обновляем итоги
        tfoot.innerHTML = `
            <tr class="table-success">
                <td><strong>ИТОГО</strong></td>
                <td><strong>${totalSalesAll.toLocaleString()} ₽</strong></td>
                <td><strong>${totalDealsAll}</strong></td>
                <td><strong>100%</strong></td>
            </tr>
        `;
        tfoot.style.display = 'table-rowgroup';
        
        console.log('Сводный отчет обновлен, партнеров: ' + sortedPartners.length);
    }
}

function updatePartnerStats() {
    console.log('Обновление статистики партнеров...');
    
    const filteredDeals = filterDealsByDate(deals, dateFilter);
    
    const totalPartnersCount = partners.length;
    const activePartnersCount = [...new Set(filteredDeals.map(deal => deal.partner))].length;
    const totalSalesAmount = filteredDeals.reduce((sum, deal) => sum + parseFloat(deal.contract_amount || 0), 0);

    const totalPartnersElement = document.getElementById('totalPartnersCount');
    const activePartnersElement = document.getElementById('activePartnersCount');
    const totalSalesElement = document.getElementById('totalSalesAmount');
    
    if (totalPartnersElement) totalPartnersElement.textContent = totalPartnersCount;
    if (activePartnersElement) activePartnersElement.textContent = activePartnersCount;
    if (totalSalesElement) totalSalesElement.textContent = totalSalesAmount.toLocaleString() + ' ₽';

    const partnerStats = {};
    
    filteredDeals.forEach(deal => {
        if (!partnerStats[deal.partner]) {
            partnerStats[deal.partner] = {
                totalSales: 0,
                totalInfo: 0,
                dealCount: 0
            };
        }
        
        partnerStats[deal.partner].totalSales += parseFloat(deal.contract_amount || 0);
        partnerStats[deal.partner].totalInfo += parseFloat(deal.info_amount || 0);
        partnerStats[deal.partner].dealCount += 1;
    });

    const tbody = document.getElementById('partnerStatsBody');
    if (!tbody) {
        console.error('Не найден элемент partnerStatsBody');
        return;
    }

    if (Object.keys(partnerStats).length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" class="text-center py-4">Нет данных для отображения</td></tr>';
    } else {
        tbody.innerHTML = Object.keys(partnerStats).map(partner => {
            const stats = partnerStats[partner];
            const avgCheck = stats.dealCount > 0 ? Math.round(stats.totalSales / stats.dealCount) : 0;
            
            // ИСПРАВЛЕННАЯ СТРОКА: безопасная обработка кавычек в data-partner
            return `
                <tr class="partner-row" data-partner="${partner.replace(/"/g, '&quot;').replace(/'/g, "&#39;")}" style="cursor: pointer;">
                    <td><strong>${partner}</strong></td>
                    <td>${stats.totalSales.toLocaleString()} ₽</td>
                    <td>${stats.totalInfo.toLocaleString()} ₽</td>
                    <td>${stats.dealCount}</td>
                    <td>${avgCheck.toLocaleString()} ₽</td>
                </tr>
            `;
        }).join('');
        
        console.log('Таблица партнеров обновлена, строк: ' + Object.keys(partnerStats).length);
    }
    
    // ОБНОВЛЯЕМ СВОДНЫЙ ОТЧЕТ
    updatePartnerSummary();
}

// ИСПРАВЛЕННАЯ ФУНКЦИЯ: Детальная статистика по партнеру
function showPartnerDetail(partnerName) {
    console.log('Показать детали для партнера:', partnerName);
    
    const filteredDeals = filterDealsByDate(deals, dateFilter);
    const partnerDeals = filteredDeals.filter(deal => deal.partner === partnerName);
    
    console.log('Найдено сделок:', partnerDeals.length);
    
    // БЕЗОПАСНОЕ ОБНОВЛЕНИЕ ТЕКСТА (без innerHTML)
    const partnerNameElement = document.getElementById('selectedPartnerName');
    if (partnerNameElement) {
        partnerNameElement.textContent = partnerName;
    }
    
    // Обновляем таблицу с деталями
    const detailTable = document.getElementById('partnerDetailTable');
    if (partnerDeals.length === 0) {
        detailTable.innerHTML = '<tr><td colspan="7" class="text-center py-4">Нет данных по сделкам этого партнера</td></tr>';
    } else {
        detailTable.innerHTML = partnerDeals.map(deal => `
            <tr>
                <td>${formatDate(deal.auth_date)}</td>
                <td>${deal.client_name}</td>
                <td>${deal.bank}</td>
                <td>${parseFloat(deal.contract_amount).toLocaleString()} ₽</td>
                <td>${parseFloat(deal.info_amount).toLocaleString()} ₽</td>
                <td>${deal.country}</td>
                <td>${deal.manager}</td>
            </tr>
        `).join('');
    }
    
    // Показываем блок с деталями
    const detailCard = document.getElementById('partnerDetailCard');
    if (detailCard) {
        detailCard.style.display = 'block';
        console.log('Детальная карточка показана');
        
        // Плавная прокрутка к деталям
        setTimeout(() => {
            detailCard.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }, 100);
    } else {
        console.error('Не найден элемент partnerDetailCard');
    }
}

// ФУНКЦИЯ СКРЫТИЯ ДЕТАЛЕЙ ПАРТНЕРА
function hidePartnerDetail() {
    const detailCard = document.getElementById('partnerDetailCard');
    if (detailCard) {
        detailCard.style.display = 'none';
        console.log('Детальная карточка скрыта');
    }
}

// НОВАЯ ФУНКЦИЯ: Экспорт сводки по партнерам в Excel (ИСПРАВЛЕННАЯ КОДИРОВКА)
function exportPartnerSummary() {
    console.log('Экспорт сводки по партнерам...');
    
    const filteredDeals = filterDealsByDate(deals, dateFilter);
    
    // Формируем CSV содержимое с правильной кодировкой
    let csv = "Партнер;Общая сумма продаж;Количество сделок;Доля рынка %\n";
    
    // Считаем статистику
    const partnerStats = {};
    let totalSalesAll = 0;
    let totalDealsAll = 0;
    
    filteredDeals.forEach(deal => {
        if (!partnerStats[deal.partner]) {
            partnerStats[deal.partner] = {
                totalSales: 0,
                dealCount: 0
            };
        }
        
        partnerStats[deal.partner].totalSales += parseFloat(deal.contract_amount || 0);
        partnerStats[deal.partner].dealCount += 1;
        
        totalSalesAll += parseFloat(deal.contract_amount || 0);
        totalDealsAll += 1;
    });
    
    // Сортируем по убыванию суммы
    const sortedPartners = Object.keys(partnerStats).sort((a, b) => 
        partnerStats[b].totalSales - partnerStats[a].totalSales
    );
    
    // Данные партнеров
    sortedPartners.forEach(partner => {
        const stats = partnerStats[partner];
        const marketShare = totalSalesAll > 0 ? ((stats.totalSales / totalSalesAll) * 100).toFixed(1) : 0;
        
        csv += `${partner};${stats.totalSales};${stats.dealCount};${marketShare}\n`;
    });
    
    // Итоговая строка
    csv += `ИТОГО;${totalSalesAll};${totalDealsAll};100\n`;
    
    // Создаем и скачиваем файл с правильной кодировкой
    const blob = new Blob(["\uFEFF" + csv], { 
        type: 'text/csv;charset=utf-8;' 
    });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    
    // Формируем имя файла с датой
    const dateFrom = document.getElementById('dateFrom').value;
    const dateTo = document.getElementById('dateTo').value;
    let filename = 'сводка_партнеров';
    
    if (dateFrom && dateTo) {
        filename += `_${dateFrom}_по_${dateTo}`;
    } else {
        filename += '_все_данные';
    }
    
    filename += '.csv';
    
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.style.display = 'none';
    
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    console.log('Сводка экспортирована');
}

function updateCountryStats() {
    const filteredDeals = filterDealsByDate(deals, dateFilter);
    
    const countryStats = {};
    const totalSales = filteredDeals.reduce((sum, deal) => sum + parseFloat(deal.contract_amount || 0), 0);
    
    filteredDeals.forEach(deal => {
        if (!countryStats[deal.country]) {
            countryStats[deal.country] = {
                totalSales: 0,
                totalInfo: 0,
                dealCount: 0
            };
        }
        
        countryStats[deal.country].totalSales += parseFloat(deal.contract_amount || 0);
        countryStats[deal.country].totalInfo += parseFloat(deal.info_amount || 0);
        countryStats[deal.country].dealCount += 1;
    });

    const tbody = document.getElementById('countryStatsTable');
    if (!tbody) return;

    if (Object.keys(countryStats).length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center py-4">Нет данных для отображения</td></tr>';
    } else {
        let tableHTML = '';
        let totalInfoAll = 0;
        let totalDealsAll = 0;
        
        Object.keys(countryStats).forEach(country => {
            const stats = countryStats[country];
            const avgCheck = stats.dealCount > 0 ? Math.round(stats.totalSales / stats.dealCount) : 0;
            const share = totalSales > 0 ? ((stats.totalSales / totalSales) * 100).toFixed(1) : 0;
            
            tableHTML += `
                <tr>
                    <td>${country}</td>
                    <td>${stats.totalSales.toLocaleString()} ₽</td>
                    <td>${stats.totalInfo.toLocaleString()} ₽</td>
                    <td>${stats.dealCount}</td>
                    <td>${avgCheck.toLocaleString()} ₽</td>
                    <td>${share}%</td>
                </tr>
            `;
            
            totalInfoAll += stats.totalInfo;
            totalDealsAll += stats.dealCount;
        });
        
        tableHTML += `
            <tr class="total-row">
                <td><strong>Итого</strong></td>
                <td><strong>${totalSales.toLocaleString()} ₽</strong></td>
                <td><strong>${totalInfoAll.toLocaleString()} ₽</strong></td>
                <td><strong>${totalDealsAll}</strong></td>
                <td><strong>${totalDealsAll > 0 ? Math.round(totalSales / totalDealsAll).toLocaleString() : 0} ₽</strong></td>
                <td><strong>100%</strong></td>
            </tr>
        `;
        
        tbody.innerHTML = tableHTML;
    }
}

// Инициализация обработчиков для статистики партнеров
document.addEventListener('DOMContentLoaded', function() {
    // Инициализация при загрузке страницы
    setTimeout(initPartnerStats, 100);
});

function initPartnerStats() {
    const tbody = document.getElementById('partnerStatsBody');
    if (tbody) {
        tbody.addEventListener('click', function(e) {
            const row = e.target.closest('.partner-row');
            if (row) {
                // ИСПРАВЛЕННАЯ СТРОКА: безопасное получение названия партнера
                const partnerName = row.getAttribute('data-partner')
                    .replace(/&quot;/g, '"')
                    .replace(/&#39;/g, "'");
                if (partnerName) {
                    showPartnerDetail(partnerName);
                }
            }
        });
    }
}

// Вспомогательные функции
function filterDealsByDate(dealsArray, filter) {
    if (!filter.from && !filter.to) {
        return dealsArray;
    }
    
    return dealsArray.filter(deal => {
        const dealDate = new Date(deal.auth_date);
        const fromDate = filter.from ? new Date(filter.from) : null;
        const toDate = filter.to ? new Date(filter.to) : null;
        
        let valid = true;
        if (fromDate) {
            valid = valid && dealDate >= fromDate;
        }
        if (toDate) {
            const toDatePlusOne = new Date(toDate);
            toDatePlusOne.setDate(toDatePlusOne.getDate() + 1);
            valid = valid && dealDate < toDatePlusOne;
        }
        
        return valid;
    });
}

function formatDate(dateString) {
    try {
        const date = new Date(dateString);
        return date.toLocaleDateString('ru-RU');
    } catch (e) {
        return dateString;
    }
}