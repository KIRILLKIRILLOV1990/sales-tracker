// Глобальные переменные для фильтров зарплат
let salaryDateFilter = { from: null, to: null };

// Инициализация фильтров зарплат
function initSalaryFilters() {
    console.log('Initializing salary filters...');
    
    // Проверяем что мы на дашборде и элементы существуют
    const dashboardSection = document.getElementById('dashboard');
    if (!dashboardSection || dashboardSection.style.display === 'none') {
        console.log('Not on dashboard, skipping salary filters initialization');
        return;
    }
    
    // Ждем чтобы DOM полностью загрузился
    setTimeout(() => {
        const dateFrom = document.getElementById('salaryDateFrom');
        const dateTo = document.getElementById('salaryDateTo');
        const quickPeriod = document.getElementById('salaryQuickPeriod');
        const periodInfo = document.getElementById('salaryPeriodInfo');
        
        if (dateFrom && dateTo && quickPeriod && periodInfo) {
            console.log('Salary filter elements found, setting defaults');
            setDefaultSalaryDateFilter();
        } else {
            console.warn('Some salary filter elements not found:', {
                dateFrom: !!dateFrom,
                dateTo: !!dateTo, 
                quickPeriod: !!quickPeriod,
                periodInfo: !!periodInfo
            });
        }
    }, 100);
}

function setDefaultSalaryDateFilter() {
    const dateFrom = document.getElementById('salaryDateFrom');
    const dateTo = document.getElementById('salaryDateTo');
    const quickPeriod = document.getElementById('salaryQuickPeriod');
    const periodInfo = document.getElementById('salaryPeriodInfo');
    
    if (!dateFrom || !dateTo || !quickPeriod || !periodInfo) {
        console.error('Salary filter elements not found');
        return;
    }
    
    const today = new Date();
    const monday = new Date(today);
    monday.setDate(today.getDate() - today.getDay() + (today.getDay() === 0 ? -6 : 1));
    const sunday = new Date(monday);
    sunday.setDate(monday.getDate() + 6);
    
    dateFrom.valueAsDate = monday;
    dateTo.valueAsDate = sunday;
    quickPeriod.value = 'currentWeek';
    
    salaryDateFilter.from = formatDateForFilter(monday);
    salaryDateFilter.to = formatDateForFilter(sunday);
    
    periodInfo.textContent = `Показана зарплата за период: ${formatDate(monday)} - ${formatDate(sunday)}`;
    
    console.log('Default salary date filter set');
}

function applySalaryDateFilter() {
    const dateFrom = document.getElementById('salaryDateFrom');
    const dateTo = document.getElementById('salaryDateTo');
    const periodInfo = document.getElementById('salaryPeriodInfo');
    
    if (!dateFrom || !dateTo || !periodInfo) {
        console.error('Salary filter elements not found');
        return;
    }
    
    const fromValue = dateFrom.value;
    const toValue = dateTo.value;
    
    if (fromValue && toValue) {
        salaryDateFilter.from = fromValue;
        salaryDateFilter.to = toValue;
        
        const fromFormatted = formatDate(fromValue);
        const toFormatted = formatDate(toValue);
        periodInfo.textContent = `Показана зарплата за период: ${fromFormatted} - ${toFormatted}`;
    } else {
        salaryDateFilter.from = null;
        salaryDateFilter.to = null;
        periodInfo.textContent = 'Показана зарплата за все время';
    }
    
    loadSalaryData();
}

function clearSalaryDateFilter() {
    const dateFrom = document.getElementById('salaryDateFrom');
    const dateTo = document.getElementById('salaryDateTo');
    const quickPeriod = document.getElementById('salaryQuickPeriod');
    const periodInfo = document.getElementById('salaryPeriodInfo');
    
    if (!dateFrom || !dateTo || !quickPeriod || !periodInfo) {
        console.error('Salary filter elements not found');
        return;
    }
    
    dateFrom.value = '';
    dateTo.value = '';
    quickPeriod.value = '';
    salaryDateFilter.from = null;
    salaryDateFilter.to = null;
    periodInfo.textContent = 'Показана зарплата за все время';
    
    loadSalaryData();
}

function applySalaryQuickPeriod() {
    const quickPeriod = document.getElementById('salaryQuickPeriod');
    const dateFrom = document.getElementById('salaryDateFrom');
    const dateTo = document.getElementById('salaryDateTo');
    
    if (!quickPeriod || !dateFrom || !dateTo) {
        console.error('Salary filter elements not found');
        return;
    }
    
    const periodValue = quickPeriod.value;
    const today = new Date();
    let dateFromValue, dateToValue;
    
    switch(periodValue) {
        case 'currentWeek':
            const monday = new Date(today);
            monday.setDate(today.getDate() - today.getDay() + (today.getDay() === 0 ? -6 : 1));
            dateFromValue = monday;
            dateToValue = new Date(monday);
            dateToValue.setDate(monday.getDate() + 6);
            break;
        case 'currentMonth':
            dateFromValue = new Date(today.getFullYear(), today.getMonth(), 1);
            dateToValue = new Date(today.getFullYear(), today.getMonth() + 1, 0);
            break;
        case 'lastWeek':
            const lastMonday = new Date(today);
            lastMonday.setDate(today.getDate() - today.getDay() - 6);
            dateFromValue = lastMonday;
            dateToValue = new Date(lastMonday);
            dateToValue.setDate(lastMonday.getDate() + 6);
            break;
        case 'lastMonth':
            dateFromValue = new Date(today.getFullYear(), today.getMonth() - 1, 1);
            dateToValue = new Date(today.getFullYear(), today.getMonth(), 0);
            break;
        default:
            return;
    }
    
    dateFrom.valueAsDate = dateFromValue;
    dateTo.valueAsDate = dateToValue;
    applySalaryDateFilter();
}

// Основная функция загрузки данных о зарплатах
function loadSalaryData() {
    console.log('Loading salary data...');
    
    const container = document.getElementById('salaryDashboardContent');
    if (!container) {
        console.error('salaryDashboardContent not found');
        return;
    }
    
    showSalaryLoading(true);
    
    let url = 'api.php?action=get_salaries';
    
    if (salaryDateFilter.from && salaryDateFilter.to) {
        url += `&date_from=${salaryDateFilter.from}&date_to=${salaryDateFilter.to}`;
    }
    
    console.log('Fetching salary data from:', url);
    
    fetch(url)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            if (data.error) {
                throw new Error(data.error);
            }
            
            if (data.success) {
                console.log('Salary data loaded successfully:', data.data);
                displaySalaryData(data.data, data.period);
            } else {
                throw new Error('Failed to load salary data');
            }
            showSalaryLoading(false);
        })
        .catch(error => {
            console.error('Error loading salary data:', error);
            showSalaryLoading(false);
            displaySalaryError(error.message);
        });
}

function displaySalaryData(salaryData, period) {
    const container = document.getElementById('salaryDashboardContent');
    if (!container) {
        console.error('salaryDashboardContent not found');
        return;
    }
    
    if (!salaryData || salaryData.length === 0) {
        container.innerHTML = `
            <div class="alert alert-info text-center">
                <h4>📊 Нет данных о зарплатах</h4>
                <p>За выбранный период нет завершенных сделок для расчета зарплат.</p>
                <small>Период: ${formatDate(period.from)} - ${formatDate(period.to)}</small>
            </div>
        `;
        return;
    }
    
    // Если данные для одного менеджера (роль manager)
    if (salaryData.length === 1 && currentUserRole !== 'admin') {
        container.innerHTML = renderManagerSalaryView(salaryData[0], period);
    } else {
        // Если данные для всех менеджеров (роль admin)
        container.innerHTML = renderAdminSalaryView(salaryData, period);
    }
}

function displaySalaryError(errorMessage) {
    const container = document.getElementById('salaryDashboardContent');
    if (!container) return;
    
    container.innerHTML = `
        <div class="alert alert-danger text-center">
            <h4>❌ Ошибка загрузки данных</h4>
            <p>${errorMessage}</p>
            <button class="btn btn-primary mt-2" onclick="loadSalaryData()">Повторить попытку</button>
        </div>
    `;
}

function showSalaryLoading(show) {
    const container = document.getElementById('salaryDashboardContent');
    if (!container) return;
    
    if (show) {
        container.innerHTML = `
            <div class="text-center py-5">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Загрузка...</span>
                </div>
                <p class="mt-2">Загрузка данных о зарплатах...</p>
            </div>
        `;
    }
}

function renderManagerSalaryView(salary, period) {
    return `
        <div class="row salary-cards">
            <div class="col-md-3">
                <div class="stat-card bg-light">
                    <h6>Общая сумма сделок</h6>
                    <h3 class="text-primary">${formatCurrency(salary.total_amount)}</h3>
                    <small>${salary.deals_count} сделок</small>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card bg-light">
                    <h6>Сделки ОТП (ЕКОМ)</h6>
                    <h3 class="text-success">${formatCurrency(salary.otp_amount)}</h3>
                    <small>Бонусные сделки +0.5%</small>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card bg-light">
                    <h6>Базовая ставка</h6>
                    <h3 class="text-info">${formatCurrency(salary.base_salary)}</h3>
                    <small>1% от суммы</small>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card bg-light">
                    <h6>Итого к выплате</h6>
                    <h3 class="text-success">${formatCurrency(salary.total_salary)}</h3>
                    <small>Зарплата</small>
                </div>
            </div>
        </div>
        
        <div class="mt-4">
            <h6>Детали расчета:</h6>
            <div class="salary-breakdown">
                <div class="row">
                    <div class="col-md-6">
                        <table class="table table-sm">
                            <tr>
                                <td><strong>Базовая ставка (1%):</strong></td>
                                <td class="text-end">${formatCurrency(salary.base_salary)}</td>
                            </tr>
                            <tr>
                                <td><strong>Бонус ОТП (0.5%):</strong></td>
                                <td class="text-end">${formatCurrency(salary.bonus_salary)}</td>
                            </tr>
                            <tr class="table-success">
                                <td><strong>ИТОГО:</strong></td>
                                <td class="text-end"><strong>${formatCurrency(salary.total_salary)}</strong></td>
                            </tr>
                        </table>
                    </div>
                    <div class="col-md-6">
                        <table class="table table-sm">
                            <tr>
                                <td>Общая сумма сделок:</td>
                                <td class="text-end">${formatCurrency(salary.total_amount)}</td>
                            </tr>
                            <tr>
                                <td>Сумма сделок ОТП:</td>
                                <td class="text-end">${formatCurrency(salary.otp_amount)}</td>
                            </tr>
                            <tr>
                                <td>Количество сделок:</td>
                                <td class="text-end">${salary.deals_count}</td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="mt-3 text-muted small">
            <i>Период расчета: ${formatDate(period.from)} - ${formatDate(period.to)}</i>
        </div>
    `;
}

function renderAdminSalaryView(salaries, period) {
    let tableHTML = `
        <div class="card">
            <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                <h5 class="mb-0">👥 Зарплаты всех менеджеров</h5>
                <span class="badge bg-light text-primary">${salaries.length} менеджеров</span>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>Менеджер</th>
                                <th>Сделки</th>
                                <th>Общая сумма</th>
                                <th>Сумма ОТП</th>
                                <th>Базовая ставка</th>
                                <th>Бонус ОТП</th>
                                <th>Итого к выплате</th>
                            </tr>
                        </thead>
                        <tbody>
    `;
    
    let totalOverall = 0;
    
    salaries.forEach(salary => {
        totalOverall += salary.total_salary;
        tableHTML += `
            <tr>
                <td><strong>${salary.manager}</strong></td>
                <td>${salary.deals_count}</td>
                <td>${formatCurrency(salary.total_amount)}</td>
                <td>${formatCurrency(salary.otp_amount)}</td>
                <td>${formatCurrency(salary.base_salary)}</td>
                <td>${formatCurrency(salary.bonus_salary)}</td>
                <td><strong class="text-success">${formatCurrency(salary.total_salary)}</strong></td>
            </tr>
        `;
    });
    
    const totalDeals = salaries.reduce((sum, s) => sum + s.deals_count, 0);
    const totalAmount = salaries.reduce((sum, s) => sum + s.total_amount, 0);
    const totalOtp = salaries.reduce((sum, s) => sum + s.otp_amount, 0);
    const totalBase = salaries.reduce((sum, s) => sum + s.base_salary, 0);
    const totalBonus = salaries.reduce((sum, s) => sum + s.bonus_salary, 0);
    
    tableHTML += `
                        </tbody>
                        <tfoot>
                            <tr class="table-success">
                                <td><strong>ВСЕГО:</strong></td>
                                <td><strong>${totalDeals}</strong></td>
                                <td><strong>${formatCurrency(totalAmount)}</strong></td>
                                <td><strong>${formatCurrency(totalOtp)}</strong></td>
                                <td><strong>${formatCurrency(totalBase)}</strong></td>
                                <td><strong>${formatCurrency(totalBonus)}</strong></td>
                                <td><strong>${formatCurrency(totalOverall)}</strong></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                
                <div class="mt-3 text-muted small">
                    <i>Период расчета: ${formatDate(period.from)} - ${formatDate(period.to)}</i>
                </div>
            </div>
        </div>
    `;
    
    return tableHTML;
}

// Вспомогательные функции
function formatDate(dateString) {
    try {
        const date = new Date(dateString);
        return date.toLocaleDateString('ru-RU');
    } catch (e) {
        return dateString;
    }
}

function formatDateForFilter(date) {
    try {
        return date.toISOString().split('T')[0];
    } catch (e) {
        return date;
    }
}

function formatCurrency(amount) {
    return new Intl.NumberFormat('ru-RU', { 
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }).format(amount) + ' ₽';
}