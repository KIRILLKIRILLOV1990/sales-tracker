// Функции для работы с настройками

function updateSettingsUI() {
    updateList('partnersList', partners, 'partners');
    updateList('banksList', banks, 'banks');
    updateList('legalEntitiesList', legalEntities, 'legal_entities');
    updateList('managersList', managers, 'managers');
    updateList('logisticsTypesList', logisticsTypes, 'logistics_types');
    updateList('countriesList', countries, 'countries');
}

function updateList(elementId, dataArray, table) {
    const container = document.getElementById(elementId);
    if (!container) return;

    if (dataArray.length === 0) {
        container.innerHTML = '<div class="text-muted text-center p-3">Нет данных</div>';
    } else {
        container.innerHTML = dataArray.map(item => `
            <div class="settings-item" id="item-${table}-${item.id}">
                <span class="item-name">${item.name}</span>
                <div class="item-actions">
                    <button class="btn btn-sm btn-outline-primary me-1" onclick="editItem('${table}', ${item.id}, '${escapeString(item.name)}')">
                        ✏️ Редактировать
                    </button>
                    <button class="btn btn-sm btn-outline-danger" onclick="removeItem('${table}', ${item.id})">
                        🗑️ Удалить
                    </button>
                </div>
            </div>
        `).join('');
    }
}

// УЛУЧШЕННАЯ ФУНКЦИЯ ДЛЯ ЭКРАНИРОВАНИЯ СТРОК
function escapeString(str) {
    return str
        .replace(/'/g, "\\'")
        .replace(/"/g, '\\"')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/&/g, '&amp;');
}

// Функции добавления
function addPartner() {
    addItem('partners', 'newPartner', 'add_partner');
}

function addBank() {
    addItem('banks', 'newBank', 'add_bank');
}

function addLegalEntity() {
    addItem('legal_entities', 'newLegalEntity', 'add_legal_entity');
}

function addManager() {
    addItem('managers', 'newManager', 'add_manager');
}

function addLogistics() {
    addItem('logistics_types', 'newLogistics', 'add_logistics');
}

function addCountry() {
    addItem('countries', 'newCountry', 'add_country');
}

// Общая функция добавления
function addItem(table, inputId, action) {
    const input = document.getElementById(inputId);
    const value = input.value.trim();
    
    if (!value) {
        alert('Введите значение!');
        return;
    }

    const formData = new FormData();
    formData.append('action', action);
    formData.append('name', value);

    fetch('api.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            input.value = '';
            loadAllData(); // Перезагружаем все данные
            showTempMessage('Элемент успешно добавлен!', 'success');
        } else {
            alert(data.error || 'Ошибка при добавлении');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Ошибка при добавлении: ' + error.message);
    });
}

// ОБНОВЛЕННАЯ ФУНКЦИЯ: Редактирование элемента с обновлением сделок
function editItem(table, id, currentName) {
    console.log('EDIT ITEM CALLED:', { table, id, currentName });
    
    const newName = prompt('Введите новое название:', currentName);
    
    if (newName === null) return; // Пользователь отменил
    if (newName.trim() === '') {
        alert('Название не может быть пустым!');
        return;
    }
    if (newName === currentName) {
        alert('Название не изменилось!');
        return;
    }
    
    console.log('Updating item:', { table, id, newName: newName.trim() });
    
    // Показываем загрузку
    const itemElement = document.getElementById(`item-${table}-${id}`);
    const originalContent = itemElement.innerHTML;
    itemElement.innerHTML = '<div class="text-center p-2"><div class="spinner-border spinner-border-sm"></div> Обновление...</div>';
    
    const formData = new FormData();
    formData.append('action', 'update_item');
    formData.append('table', table);
    formData.append('id', id);
    formData.append('name', newName.trim());

    console.log('Sending request to API...');
    
    fetch('api.php', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        console.log('Response status:', response.status);
        return response.json();
    })
    .then(data => {
        console.log('API Response:', data);
        if (data.success) {
            // Обновляем интерфейс без перезагрузки всей страницы
            const itemElement = document.getElementById(`item-${table}-${id}`);
            if (itemElement) {
                // БЕЗОПАСНОЕ ОБНОВЛЕНИЕ С ИСПРАВЛЕННЫМ ЭКРАНИРОВАНИЕМ
                itemElement.innerHTML = `
                    <span class="item-name">${newName.trim()}</span>
                    <div class="item-actions">
                        <button class="btn btn-sm btn-outline-primary me-1" onclick="editItem('${table}', ${id}, '${escapeString(newName.trim())}')">
                            ✏️ Редактировать
                        </button>
                        <button class="btn btn-sm btn-outline-danger" onclick="removeItem('${table}', ${id})">
                            🗑️ Удалить
                        </button>
                    </div>
                `;
            }
            
            // ПОКАЗЫВАЕМ ИНФОРМАЦИЮ ОБ ОБНОВЛЕННЫХ СДЕЛКАХ
            let message = data.message || 'Элемент успешно обновлен!';
            showTempMessage(message, 'success');
            
            // ПЕРЕЗАГРУЖАЕМ ДАННЫЕ ЧТОБЫ ОБНОВИТЬ ВСЕ ТАБЛИЦЫ
            setTimeout(() => {
                loadAllData();
            }, 1500);
            
        } else {
            // Восстанавливаем оригинальное содержимое при ошибке
            if (itemElement) {
                itemElement.innerHTML = originalContent;
            }
            alert('Ошибка при обновлении: ' + (data.error || 'Неизвестная ошибка'));
        }
    })
    .catch(error => {
        console.error('Error:', error);
        // Восстанавливаем оригинальное содержимое при ошибке
        if (itemElement) {
            itemElement.innerHTML = originalContent;
        }
        alert('Ошибка при обновлении: ' + error.message);
    });
}

// Функция удаления
function removeItem(table, id) {
    if (!confirm('Вы уверены, что хотите удалить этот элемент?')) return;

    const formData = new FormData();
    formData.append('action', 'remove_item');
    formData.append('table', table);
    formData.append('id', id);

    fetch('api.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            loadAllData();
            showTempMessage('Элемент успешно удален!', 'success');
        } else {
            alert(data.error || 'Ошибка при удалении');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Ошибка при удалении: ' + error.message);
    });
}

// Вспомогательная функция для показа временных сообщений
function showTempMessage(message, type = 'info') {
    const alertClass = type === 'success' ? 'alert-success' : 'alert-info';
    const messageDiv = document.createElement('div');
    messageDiv.className = `alert ${alertClass} alert-dismissible fade show`;
    messageDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    // Добавляем сообщение в начало страницы
    const firstCard = document.querySelector('.settings-card');
    if (firstCard) {
        firstCard.parentNode.insertBefore(messageDiv, firstCard);
    }
    
    // Автоматически скрываем через 5 секунд
    setTimeout(() => {
        if (messageDiv.parentNode) {
            messageDiv.remove();
        }
    }, 5000);
}

// Обработка Enter в полях ввода настроек
document.addEventListener('DOMContentLoaded', function() {
    const inputs = ['newPartner', 'newBank', 'newLegalEntity', 'newManager', 'newLogistics', 'newCountry'];
    inputs.forEach(inputId => {
        const input = document.getElementById(inputId);
        if (input) {
            input.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    const type = inputId.replace('new', '').toLowerCase();
                    if (type === 'partner') addPartner();
                    else if (type === 'bank') addBank();
                    else if (type === 'legalentity') addLegalEntity();
                    else if (type === 'manager') addManager();
                    else if (type === 'logistics') addLogistics();
                    else if (type === 'country') addCountry();
                }
            });
        }
    });
});