// main.js - главный контроллер приложения

// Глобальные переменные для данных
let partners = [];
let banks = [];
let legalEntities = [];
let managers = [];
let logisticsTypes = [];
let countries = [];
let deals = [];
let dateFilter = { from: null, to: null };
let dealsDateFilter = { from: null, to: null };
let currentSection = 'dashboard';

// Инициализация при загрузке
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM loaded, initializing application...');
    
    // Ждем полной загрузки DOM
    setTimeout(() => {
        initializeApplication();
    }, 100);
});

function initializeApplication() {
    // Восстанавливаем последний раздел или используем dashboard
    const savedSection = sessionStorage.getItem('currentSection');
    if (savedSection && document.getElementById(savedSection)) {
        currentSection = savedSection;
    }
    
    applyRoleRestrictions();
    loadAllData();
    
    // Инициализируем обработчики событий
    initializeEventListeners();
    
    // Показываем начальный раздел
    showSection(currentSection);
}

function initializeEventListeners() {
    const dealForm = document.getElementById('dealForm');
    if (dealForm) {
        dealForm.addEventListener('submit', function(e) {
            e.preventDefault();
            saveDeal();
        });
    }
    
    // Инициализируем даты
    const authDate = document.getElementById('authDate');
    if (authDate) {
        authDate.valueAsDate = new Date();
    }
    
    setDefaultDealsDateFilter();
}

function applyRoleRestrictions() {
    const settingsLink = document.getElementById('settingsLink');
    const partnerStatsLink = document.getElementById('partnerStatsLink');
    const partnersLink = document.getElementById('partnersLink');
    const addDealLink = document.getElementById('addDealLink');
    
    if (!settingsLink || !partnerStatsLink || !partnersLink || !addDealLink) return;
    
    switch(currentUserRole) {
        case 'manager':
            settingsLink.style.display = 'none';
            partnerStatsLink.style.display = 'none';
            partnersLink.style.display = 'none';
            break;
        case 'logistics':
            settingsLink.style.display = 'none';
            partnerStatsLink.style.display = 'none';
            partnersLink.style.display = 'none';
            addDealLink.style.display = 'none';
            break;
    }
}

// Загрузка всех данных
function loadAllData() {
    showLoading(true);
    
    console.log('Loading data from api.php...');
    
    fetch('api.php?action=get_all_data')
        .then(response => {
            console.log('Response status:', response.status);
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            console.log('API response received:', data);
            
            if (data.error) {
                throw new Error(data.error);
            }
            
            // Правильное присвоение данных
            partners = data.partners || [];
            banks = data.banks || [];
            legalEntities = data.legal_entities || [];
            managers = data.managers || [];
            logisticsTypes = data.logistics_types || [];
            countries = data.countries || [];
            deals = data.deals || [];
            
            console.log('Data loaded successfully:', {
                partners: partners.length,
                banks: banks.length,
                legalEntities: legalEntities.length,
                managers: managers.length,
                logisticsTypes: logisticsTypes.length,
                countries: countries.length,
                deals: deals.length
            });
            
            updateSettingsUI();
            updateCurrentSection();
            showLoading(false);
        })
        .catch(error => {
            console.error('Error loading data:', error);
            showLoading(false);
            alert('Ошибка загрузки данных. Проверьте консоль для подробностей.');
        });
}

function showLoading(show) {
    const main = document.querySelector('main');
    if (main) {
        if (show) {
            main.classList.add('loading');
        } else {
            main.classList.remove('loading');
        }
    }
}

// ОБНОВЛЕННАЯ ФУНКЦИЯ: Добавлена обработка раздела логистики
function updateCurrentSection() {
    console.log('Updating current section:', currentSection);
    
    if (currentSection === 'dashboard') {
        initializeSalaryDashboard();
        loadLogisticsStats();
    } else if (currentSection === 'deals') {
        // Инициализируем поиск и пагинацию для сделок
        setTimeout(() => {
            if (typeof initDealsSearch === 'function') {
                initDealsSearch();
            }
            if (typeof updateDealsTableWithSearch === 'function') {
                updateDealsTableWithSearch();
            }
        }, 100);
    } else if (currentSection === 'partner-stats') {
        updatePartnerStats();
        updateCountryStats();
    } else if (currentSection === 'logistics') {
        // Используем новую систему логистики, если она есть, иначе старую
        if (typeof initLogistics === 'function') {
            setTimeout(initLogistics, 100);
        } else {
            updateLogisticsTable();
        }
    } else if (currentSection === 'partners') {
        // Загрузка данных партнеров происходит автоматически через partners.js
        console.log('Partners section loaded - data will load automatically');
    } else if (currentSection === 'settings') {
        updateSettingsUI();
    }
    
    updateDealForm();
}

function showSection(sectionId) {
    console.log('Showing section:', sectionId);
    
    // Проверки прав доступа
    if ((sectionId === 'partner-stats' || sectionId === 'partners' || sectionId === 'settings' || sectionId === 'user-management') && 
        (currentUserRole === 'manager' || currentUserRole === 'logistics')) {
        alert('❌ Доступ запрещен. Только для администраторов.');
        return;
    }
    
    if (sectionId === 'user-management' && currentUserRole !== 'admin') {
        alert('❌ Доступ к управлению пользователями запрещен. Только для администраторов.');
        return;
    }
    
    currentSection = sectionId;
    sessionStorage.setItem('currentSection', sectionId);
    
    // Скрываем все секции
    document.querySelectorAll('.content-section').forEach(section => {
        if (section) {
            section.style.display = 'none';
        }
    });
    
    // Показываем целевую секцию
    const targetSection = document.getElementById(sectionId);
    if (targetSection) {
        targetSection.style.display = 'block';
        console.log('Section displayed:', sectionId);
    }
    
    // Обновляем активные ссылки
    document.querySelectorAll('.sidebar a').forEach(link => {
        if (link) {
            link.classList.remove('active');
        }
    });
    
    const activeLink = document.querySelector(`.sidebar a[href="#${sectionId}"]`);
    if (activeLink) {
        activeLink.classList.add('active');
    }
    
    updateCurrentSection();
}

// Функции для дашборда зарплат
function initializeSalaryDashboard() {
    console.log('Initializing salary dashboard...');
    
    setTimeout(() => {
        initializeSalaryFilters();
        loadSalaryData();
    }, 200);
}

function initializeSalaryFilters() {
    const dateFrom = document.getElementById('salaryDateFrom');
    const dateTo = document.getElementById('salaryDateTo');
    const quickPeriod = document.getElementById('salaryQuickPeriod');
    const periodInfo = document.getElementById('salaryPeriodInfo');
    
    if (!dateFrom || !dateTo || !quickPeriod || !periodInfo) {
        setTimeout(initializeSalaryFilters, 100);
        return;
    }
    
    const today = new Date();
    const monday = new Date(today);
    monday.setDate(today.getDate() - today.getDay() + (today.getDay() === 0 ? -6 : 1));
    const sunday = new Date(monday);
    sunday.setDate(monday.getDate() + 6);
    
    dateFrom.valueAsDate = monday;
    dateTo.valueAsDate = sunday;
    quickPeriod.value = 'currentWeek';
    
    window.salaryDateFilter = {
        from: formatDateForFilter(monday),
        to: formatDateForFilter(sunday)
    };
    
    periodInfo.textContent = `Показана зарплата за период: ${formatDate(monday)} - ${formatDate(sunday)}`;
}

function applySalaryDateFilter() {
    const dateFrom = document.getElementById('salaryDateFrom');
    const dateTo = document.getElementById('salaryDateTo');
    const periodInfo = document.getElementById('salaryPeriodInfo');
    
    if (!dateFrom || !dateTo || !periodInfo) return;
    
    const fromValue = dateFrom.value;
    const toValue = dateTo.value;
    
    if (fromValue && toValue) {
        window.salaryDateFilter = {
            from: fromValue,
            to: toValue
        };
        
        periodInfo.textContent = `Показана зарплата за период: ${formatDate(fromValue)} - ${formatDate(toValue)}`;
    } else {
        window.salaryDateFilter = { from: null, to: null };
        periodInfo.textContent = 'Показана зарплата за все время';
    }
    
    loadSalaryData();
}

function loadSalaryData() {
    const container = document.getElementById('salaryDashboardContent');
    if (!container) return;
    
    container.innerHTML = `
        <div class="text-center py-5">
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Загрузка...</span>
            </div>
            <p class="mt-2">Загрузка данных о зарплатах...</p>
        </div>
    `;
    
    let url = 'api.php?action=get_salaries';
    
    if (window.salaryDateFilter && window.salaryDateFilter.from && window.salaryDateFilter.to) {
        url += `&date_from=${window.salaryDateFilter.from}&date_to=${window.salaryDateFilter.to}`;
    }
    
    fetch(url)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                displaySalaryData(data.data, data.period);
            } else {
                throw new Error(data.error || 'Failed to load salary data');
            }
        })
        .catch(error => {
            console.error('Error loading salary data:', error);
            container.innerHTML = `
                <div class="alert alert-danger text-center">
                    <h4>❌ Ошибка загрузки данных</h4>
                    <p>${error.message}</p>
                    <button class="btn btn-primary mt-2" onclick="loadSalaryData()">Повторить попытку</button>
                </div>
            `;
        });
}

function displaySalaryData(salaryData, period) {
    const container = document.getElementById('salaryDashboardContent');
    if (!container) return;
    
    if (!salaryData || salaryData.length === 0) {
        container.innerHTML = `
            <div class="alert alert-info text-center">
                <h4>📊 Нет данных о зарплатах</h4>
                <p>За выбранный период нет сделок для расчета зарплат.</p>
            </div>
        `;
        return;
    }
    
    if (salaryData.length === 1 && currentUserRole !== 'admin') {
        container.innerHTML = renderManagerSalaryView(salaryData[0], period);
    } else {
        container.innerHTML = renderAdminSalaryView(salaryData, period);
    }
}

function renderManagerSalaryView(salary, period) {
    return `
        <div class="row">
            <div class="col-12">
                <div class="card mb-4">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">👤 Моя заработная плата</h5>
                    </div>
                    <div class="card-body">
                        <div class="row text-center">
                            <div class="col-md-3">
                                <div class="stat-card bg-light">
                                    <h6>Общая сумма сделок</h6>
                                    <h3 class="text-primary">${formatCurrency(salary.total_amount)}</h3>
                                    <small>${salary.deals_count} сделок</small>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="stat-card bg-light">
                                    <h6>Сделки ОТП (ЕКОМ)</h6>
                                    <h3 class="text-success">${formatCurrency(salary.otp_amount)}</h3>
                                    <small>Бонусные сделки +0.5%</small>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="stat-card bg-light">
                                    <h6>Базовая ставка</h6>
                                    <h3 class="text-info">${formatCurrency(salary.base_salary)}</h3>
                                    <small>1% от суммы</small>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="stat-card bg-light">
                                    <h6>Итого к выплате</h6>
                                    <h3 class="text-success">${formatCurrency(salary.total_salary)}</h3>
                                    <small>Зарплата</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
}

function renderAdminSalaryView(salaries, period) {
    let tableHTML = `
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">👥 Зарплаты всех менеджеров</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>Менеджер</th>
                                <th>Сделки</th>
                                <th>Общая сумма</th>
                                <th>Сумма ОТП (ЕКОМ)</th>
                                <th>Базовая ставка</th>
                                <th>Бонус ОТП (ЕКОМ)</th>
                                <th>Итого к выплате</th>
                            </tr>
                        </thead>
                        <tbody>
    `;
    
    salaries.forEach(salary => {
        tableHTML += `
            <tr>
                <td><strong>${salary.manager}</strong></td>
                <td>${salary.deals_count}</td>
                <td>${formatCurrency(salary.total_amount)}</td>
                <td>${formatCurrency(salary.otp_amount)}</td>
                <td>${formatCurrency(salary.base_salary)}</td>
                <td>${formatCurrency(salary.bonus_salary)}</td>
                <td><strong class="text-success">${formatCurrency(salary.total_salary)}</strong></td>
            </tr>
        `;
    });
    
    tableHTML += `
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    `;
    
    return tableHTML;
}

// Загрузка статистики логистики
function loadLogisticsStats() {
    console.log('Loading logistics stats...');
    
    fetch('api.php?action=get_pending_logistics_stats')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const widget = document.getElementById('logisticsStatusWidget');
                const pendingDealsCount = document.getElementById('pendingDealsCount');
                const userPendingDealsCount = document.getElementById('userPendingDealsCount');
                const userPendingTitle = document.getElementById('userPendingTitle');
                const userPendingText = document.getElementById('userPendingText');
                
                if (data.stats.total_pending > 0) {
                    // Показываем виджет
                    widget.style.display = 'block';
                    
                    // Обновляем общее количество ожидающих сделок
                    pendingDealsCount.textContent = data.stats.total_pending;
                    
                    // Обновляем персональные ожидающие сделки (для менеджера)
                    userPendingDealsCount.textContent = data.stats.user_pending;
                    
                    // Настраиваем текст в зависимости от роли
                    if (currentUserRole === 'manager') {
                        userPendingTitle.textContent = 'Ваши ожидающие сделки';
                        userPendingText.textContent = 'Ваши сделки';
                    } else {
                        userPendingTitle.textContent = 'Ожидающие сделки';
                        userPendingText.textContent = 'Всего сделок';
                    }
                } else {
                    // Скрываем виджет, если нет ожидающих сделок
                    widget.style.display = 'none';
                }
            } else {
                console.error('Error loading logistics stats:', data.error);
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
}

// Вспомогательные функции
function formatDate(dateString) {
    try {
        const date = new Date(dateString);
        return date.toLocaleDateString('ru-RU');
    } catch (e) {
        return dateString;
    }
}

function formatDateForFilter(date) {
    try {
        return date.toISOString().split('T')[0];
    } catch (e) {
        return date;
    }
}

function formatCurrency(amount) {
    return new Intl.NumberFormat('ru-RU', { 
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }).format(amount) + ' ₽';
}

// Заглушки для функций из других файлов
function setDefaultDealsDateFilter() {}
function updateDealsTable() {}
function updateLogisticsTable() {}
function updateDealForm() {}
function updateSettingsUI() {
    console.log('updateSettingsUI called - this should be defined in settings.js');
}
function updatePartnerStats() {}
function updateCountryStats() {}
function saveDeal() {}