// search-pagination.js - поиск и пагинация для сделок

// Глобальные переменные для поиска и пагинации
let dealsSearchState = {
    clientName: '',
    manager: '',
    status: '',
    currentPage: 1,
    pageSize: 50
};

// Инициализация поиска
function initDealsSearch() {
    console.log('Initializing deals search...');
    
    // Заполняем select менеджеров
    updateManagerSearchSelect();
    
    // Восстанавливаем состояние поиска из sessionStorage
    loadSearchState();
    
    // Применяем поиск если есть сохраненные параметры
    if (dealsSearchState.clientName || dealsSearchState.manager || dealsSearchState.status) {
        applySearch();
    }
}

// Обновление select менеджеров
function updateManagerSearchSelect() {
    const managerSelect = document.getElementById('searchManager');
    if (!managerSelect) return;
    
    // Очищаем и добавляем опции
    managerSelect.innerHTML = '<option value="">Все менеджеры</option>';
    
    if (managers && managers.length > 0) {
        managers.forEach(manager => {
            const option = document.createElement('option');
            option.value = manager.name;
            option.textContent = manager.name;
            managerSelect.appendChild(option);
        });
    }
}

// Применение поиска
function applySearch() {
    const clientName = document.getElementById('searchClientName').value.trim();
    const manager = document.getElementById('searchManager').value;
    const status = document.getElementById('searchStatus').value;
    
    // Обновляем состояние поиска
    dealsSearchState.clientName = clientName;
    dealsSearchState.manager = manager;
    dealsSearchState.status = status;
    dealsSearchState.currentPage = 1; // Сбрасываем на первую страницу
    
    // Сохраняем состояние
    saveSearchState();
    
    // Обновляем таблицу
    updateDealsTableWithSearch();
    
    // Показываем информацию о поиске
    showSearchInfo();
}

// Очистка поиска
function clearSearch() {
    document.getElementById('searchClientName').value = '';
    document.getElementById('searchManager').value = '';
    document.getElementById('searchStatus').value = '';
    
    dealsSearchState.clientName = '';
    dealsSearchState.manager = '';
    dealsSearchState.status = '';
    dealsSearchState.currentPage = 1;
    
    // Очищаем sessionStorage
    sessionStorage.removeItem('dealsSearchState');
    
    // Скрываем информацию о поиске
    document.getElementById('searchResultsInfo').style.display = 'none';
    
    // Обновляем таблицу
    updateDealsTableWithSearch();
}

// Фильтрация сделок по поисковым параметрам
function filterDealsBySearch(dealsArray) {
    if (!dealsArray) return [];
    
    let filtered = [...dealsArray];
    
    // Фильтр по ФИО клиента
    if (dealsSearchState.clientName) {
        const searchTerm = dealsSearchState.clientName.toLowerCase();
        filtered = filtered.filter(deal => 
            deal.client_name && deal.client_name.toLowerCase().includes(searchTerm)
        );
    }
    
    // Фильтр по менеджеру
    if (dealsSearchState.manager) {
        filtered = filtered.filter(deal => deal.manager === dealsSearchState.manager);
    }
    
    // Фильтр по статусу
    if (dealsSearchState.status) {
        filtered = filtered.filter(deal => deal.status === dealsSearchState.status);
    }
    
    return filtered;
}

// Обновление таблицы с учетом поиска и пагинации
function updateDealsTableWithSearch() {
    const tbody = document.getElementById('dealsTable');
    if (!tbody) return;

    // Применяем фильтр по дате
    let filteredDeals = filterDealsByDate(deals, dealsDateFilter);
    
    // Применяем поисковые фильтры
    filteredDeals = filterDealsBySearch(filteredDeals);
    
    // Применяем пагинацию
    const paginatedDeals = applyPagination(filteredDeals);
    
    // Обновляем UI пагинации
    updatePaginationUI(filteredDeals.length);
    
    // Рендерим таблицу
    if (paginatedDeals.length === 0) {
        tbody.innerHTML = '<tr><td colspan="17" class="text-center py-4">' + 
            (dealsSearchState.clientName || dealsSearchState.manager || dealsSearchState.status ? 
             'Не найдено сделок по вашему запросу' : 'Нет данных о сделках за выбранный период') + 
            '</td></tr>';
    } else {
        tbody.innerHTML = paginatedDeals.map((deal, index) => {
            const globalIndex = (dealsSearchState.currentPage - 1) * dealsSearchState.pageSize + index + 1;
            
            return `
                <tr>
                    <td><span class="deal-number">${deal.id}</span></td>
                    <td>${formatDate(deal.auth_date)}</td>
                    <td>${deal.partner}</td>
                    <td><strong>${deal.client_name}</strong></td>
                    <td>${deal.bank}</td>
                    <td>${parseFloat(deal.contract_amount).toLocaleString('ru-RU')} ₽</td>
                    <td>${parseFloat(deal.info_amount).toLocaleString('ru-RU')} ₽</td>
                    <td>${parseFloat(deal.no_info_amount).toLocaleString('ru-RU')} ₽</td>
                    <td>${deal.interest_rate}%</td>
                    <td>${deal.installment_period} мес.</td>
                    <td>${deal.contract_number}</td>
                    <td>${deal.country}</td>
                    <td>${deal.client_email || '-'}</td>
                    <td>${deal.client_phone || '-'}</td>
                    <td><span class="badge bg-primary">${deal.manager}</span></td>
                    <td><span class="logistics-status ${deal.status === 'completed' ? 'status-completed' : 'status-pending'}">${deal.status === 'completed' ? 'Завершено' : 'В процессе'}</span></td>
                    <td>
                        <div class="btn-group btn-group-sm" role="group">
                            ${currentUserRole === 'admin' || currentUserRole === 'manager' ? 
                                `<button class="btn btn-outline-primary" onclick="editDeal(${deal.id})" title="Редактировать">
                                    ✏️
                                </button>` : ''
                            }
                            ${currentUserRole === 'admin' ? 
                                `<button class="btn btn-outline-danger" onclick="deleteDeal(${deal.id}, '${deal.client_name.replace(/'/g, "\\'")}')" title="Удалить">
                                    🗑️
                                </button>` : ''
                            }
                        </div>
                    </td>
                </tr>
            `;
        }).join('');
    }
}

// Пагинация
function applyPagination(dealsArray) {
    const startIndex = (dealsSearchState.currentPage - 1) * dealsSearchState.pageSize;
    const endIndex = startIndex + dealsSearchState.pageSize;
    return dealsArray.slice(startIndex, endIndex);
}

// Обновление UI пагинации
function updatePaginationUI(totalItems) {
    const paginationElement = document.getElementById('dealsPagination');
    if (!paginationElement) return;
    
    const totalPages = Math.ceil(totalItems / dealsSearchState.pageSize);
    
    if (totalPages <= 1) {
        paginationElement.innerHTML = '';
        return;
    }
    
    let paginationHTML = `
        <ul class="pagination justify-content-center">
    `;
    
    // Кнопка "Назад"
    const prevDisabled = dealsSearchState.currentPage === 1 ? 'disabled' : '';
    paginationHTML += `
        <li class="page-item ${prevDisabled}">
            <a class="page-link" href="#" onclick="changeDealsPage(${dealsSearchState.currentPage - 1})" ${prevDisabled ? 'tabindex="-1" aria-disabled="true"' : ''}>
                &laquo;
            </a>
        </li>
    `;
    
    // Номера страниц
    const maxVisiblePages = 5;
    let startPage = Math.max(1, dealsSearchState.currentPage - Math.floor(maxVisiblePages / 2));
    let endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);
    
    // Корректируем если в начале
    if (endPage - startPage + 1 < maxVisiblePages) {
        startPage = Math.max(1, endPage - maxVisiblePages + 1);
    }
    
    for (let i = startPage; i <= endPage; i++) {
        const activeClass = i === dealsSearchState.currentPage ? 'active' : '';
        paginationHTML += `
            <li class="page-item ${activeClass}">
                <a class="page-link" href="#" onclick="changeDealsPage(${i})">${i}</a>
            </li>
        `;
    }
    
    // Кнопка "Вперед"
    const nextDisabled = dealsSearchState.currentPage === totalPages ? 'disabled' : '';
    paginationHTML += `
        <li class="page-item ${nextDisabled}">
            <a class="page-link" href="#" onclick="changeDealsPage(${dealsSearchState.currentPage + 1})" ${nextDisabled ? 'tabindex="-1" aria-disabled="true"' : ''}>
                &raquo;
            </a>
        </li>
    `;
    
    paginationHTML += `</ul>`;
    
    // Информация о странице
    const startItem = (dealsSearchState.currentPage - 1) * dealsSearchState.pageSize + 1;
    const endItem = Math.min(dealsSearchState.currentPage * dealsSearchState.pageSize, totalItems);
    
    paginationHTML += `
        <div class="text-center mt-2 text-muted small">
            Показано ${startItem}-${endItem} из ${totalItems} сделок
            ${totalPages > 1 ? `(Страница ${dealsSearchState.currentPage} из ${totalPages})` : ''}
        </div>
    `;
    
    paginationElement.innerHTML = paginationHTML;
}

// Смена страницы
function changeDealsPage(newPage) {
    dealsSearchState.currentPage = newPage;
    saveSearchState();
    updateDealsTableWithSearch();
    
    // Прокручиваем к верху таблицы
    const table = document.getElementById('dealsTable');
    if (table) {
        table.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
}

// Показ информации о поиске
function showSearchInfo() {
    const infoElement = document.getElementById('searchResultsInfo');
    const textElement = document.getElementById('searchResultsText');
    
    if (!dealsSearchState.clientName && !dealsSearchState.manager && !dealsSearchState.status) {
        infoElement.style.display = 'none';
        return;
    }
    
    let searchText = '🔍 Применен поиск: ';
    const conditions = [];
    
    if (dealsSearchState.clientName) {
        conditions.push(`клиент: "${dealsSearchState.clientName}"`);
    }
    
    if (dealsSearchState.manager) {
        conditions.push(`менеджер: ${dealsSearchState.manager}`);
    }
    
    if (dealsSearchState.status) {
        const statusText = dealsSearchState.status === 'completed' ? 'Завершено' : 'В процессе';
        conditions.push(`статус: ${statusText}`);
    }
    
    searchText += conditions.join(', ');
    
    textElement.textContent = searchText;
    infoElement.style.display = 'flex';
}

// Сохранение состояния поиска
function saveSearchState() {
    try {
        sessionStorage.setItem('dealsSearchState', JSON.stringify(dealsSearchState));
    } catch (e) {
        console.warn('Cannot save search state to sessionStorage');
    }
}

// Загрузка состояния поиска
function loadSearchState() {
    try {
        const saved = sessionStorage.getItem('dealsSearchState');
        if (saved) {
            const parsed = JSON.parse(saved);
            dealsSearchState = { ...dealsSearchState, ...parsed };
            
            // Восстанавливаем значения полей
            document.getElementById('searchClientName').value = dealsSearchState.clientName || '';
            document.getElementById('searchManager').value = dealsSearchState.manager || '';
            document.getElementById('searchStatus').value = dealsSearchState.status || '';
        }
    } catch (e) {
        console.warn('Cannot load search state from sessionStorage');
    }
}

// Инициализация при загрузке страницы
document.addEventListener('DOMContentLoaded', function() {
    // Инициализируем поиск с небольшой задержкой чтобы данные успели загрузиться
    setTimeout(initDealsSearch, 500);
});