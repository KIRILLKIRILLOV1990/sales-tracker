function setDefaultDealsDateFilter() {
    const today = new Date();
    const firstDayOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
    
    document.getElementById('dealsDateFrom').valueAsDate = firstDayOfMonth;
    document.getElementById('dealsDateTo').valueAsDate = today;
    document.getElementById('dealsQuickPeriod').value = 'month';
    
    dealsDateFilter.from = formatDateForFilter(firstDayOfMonth);
    dealsDateFilter.to = formatDateForFilter(today);
    
    document.getElementById('dealsPeriodInfo').textContent = 
        `Показаны данные за период: ${formatDate(firstDayOfMonth)} - ${formatDate(today)}`;
}

function applyDealsDateFilter() {
    const dateFrom = document.getElementById('dealsDateFrom').value;
    const dateTo = document.getElementById('dealsDateTo').value;
    
    if (dateFrom && dateTo) {
        dealsDateFilter.from = dateFrom;
        dealsDateFilter.to = dateTo;
        
        const fromFormatted = formatDate(dateFrom);
        const toFormatted = formatDate(dateTo);
        document.getElementById('dealsPeriodInfo').textContent = 
            `Показаны данные за период: ${fromFormatted} - ${toFormatted}`;
    } else {
        dealsDateFilter.from = null;
        dealsDateFilter.to = null;
        document.getElementById('dealsPeriodInfo').textContent = 'Показаны все данные';
    }
    
    updateDealsTable();
}

function clearDealsDateFilter() {
    document.getElementById('dealsDateFrom').value = '';
    document.getElementById('dealsDateTo').value = '';
    document.getElementById('dealsQuickPeriod').value = '';
    dealsDateFilter.from = null;
    dealsDateFilter.to = null;
    document.getElementById('dealsPeriodInfo').textContent = 'Показаны все данные';
    
    updateDealsTable();
}

function applyDealsQuickPeriod() {
    const quickPeriod = document.getElementById('dealsQuickPeriod').value;
    const today = new Date();
    let dateFrom, dateTo;
    
    switch(quickPeriod) {
        case 'today':
            dateFrom = today;
            dateTo = today;
            break;
        case 'yesterday':
            const yesterday = new Date(today);
            yesterday.setDate(yesterday.getDate() - 1);
            dateFrom = yesterday;
            dateTo = yesterday;
            break;
        case 'week':
            const startOfWeek = new Date(today);
            startOfWeek.setDate(today.getDate() - today.getDay() + (today.getDay() === 0 ? -6 : 1));
            dateFrom = startOfWeek;
            dateTo = today;
            break;
        case 'month':
            dateFrom = new Date(today.getFullYear(), today.getMonth(), 1);
            dateTo = today;
            break;
        case 'quarter':
            const quarter = Math.floor(today.getMonth() / 3);
            dateFrom = new Date(today.getFullYear(), quarter * 3, 1);
            dateTo = today;
            break;
        case 'year':
            dateFrom = new Date(today.getFullYear(), 0, 1);
            dateTo = today;
            break;
        case 'lastMonth':
            const lastMonth = new Date(today.getFullYear(), today.getMonth() - 1, 1);
            dateFrom = lastMonth;
            dateTo = new Date(today.getFullYear(), today.getMonth(), 0);
            break;
        case 'lastQuarter':
            const lastQuarter = Math.floor((today.getMonth() - 3) / 3);
            const lastQuarterYear = lastQuarter < 0 ? today.getFullYear() - 1 : today.getFullYear();
            const lastQuarterMonth = lastQuarter < 0 ? (lastQuarter + 4) * 3 : lastQuarter * 3;
            dateFrom = new Date(lastQuarterYear, lastQuarterMonth, 1);
            dateTo = new Date(lastQuarterYear, lastQuarterMonth + 3, 0);
            break;
        case 'lastYear':
            dateFrom = new Date(today.getFullYear() - 1, 0, 1);
            dateTo = new Date(today.getFullYear() - 1, 11, 31);
            break;
        default:
            return;
    }
    
    document.getElementById('dealsDateFrom').valueAsDate = dateFrom;
    document.getElementById('dealsDateTo').valueAsDate = dateTo;
    applyDealsDateFilter();
}

function applyDateFilter() {
    const dateFrom = document.getElementById('dateFrom').value;
    const dateTo = document.getElementById('dateTo').value;
    
    if (dateFrom && dateTo) {
        dateFilter.from = dateFrom;
        dateFilter.to = dateTo;
        
        const fromFormatted = formatDate(dateFrom);
        const toFormatted = formatDate(dateTo);
        document.getElementById('periodInfo').textContent = `Показаны данные за период: ${fromFormatted} - ${toFormatted}`;
    } else {
        dateFilter.from = null;
        dateFilter.to = null;
        document.getElementById('periodInfo').textContent = 'Показаны все данные';
    }
    
    updatePartnerStats();
    updateCountryStats();
    updateDashboard();
}

function clearDateFilter() {
    document.getElementById('dateFrom').value = '';
    document.getElementById('dateTo').value = '';
    document.getElementById('quickPeriod').value = '';
    dateFilter.from = null;
    dateFilter.to = null;
    document.getElementById('periodInfo').textContent = 'Показаны все данные';
    
    updatePartnerStats();
    updateCountryStats();
    updateDashboard();
}

function applyQuickPeriod() {
    const quickPeriod = document.getElementById('quickPeriod').value;
    const today = new Date();
    let dateFrom, dateTo;
    
    switch(quickPeriod) {
        case 'today':
            dateFrom = today;
            dateTo = today;
            break;
        case 'yesterday':
            const yesterday = new Date(today);
            yesterday.setDate(yesterday.getDate() - 1);
            dateFrom = yesterday;
            dateTo = yesterday;
            break;
        case 'week':
            const startOfWeek = new Date(today);
            startOfWeek.setDate(today.getDate() - today.getDay() + (today.getDay() === 0 ? -6 : 1));
            dateFrom = startOfWeek;
            dateTo = today;
            break;
        case 'month':
            dateFrom = new Date(today.getFullYear(), today.getMonth(), 1);
            dateTo = today;
            break;
        case 'quarter':
            const quarter = Math.floor(today.getMonth() / 3);
            dateFrom = new Date(today.getFullYear(), quarter * 3, 1);
            dateTo = today;
            break;
        case 'year':
            dateFrom = new Date(today.getFullYear(), 0, 1);
            dateTo = today;
            break;
        case 'lastMonth':
            const lastMonth = new Date(today.getFullYear(), today.getMonth() - 1, 1);
            dateFrom = lastMonth;
            dateTo = new Date(today.getFullYear(), today.getMonth(), 0);
            break;
        case 'lastQuarter':
            const lastQuarter = Math.floor((today.getMonth() - 3) / 3);
            const lastQuarterYear = lastQuarter < 0 ? today.getFullYear() - 1 : today.getFullYear();
            const lastQuarterMonth = lastQuarter < 0 ? (lastQuarter + 4) * 3 : lastQuarter * 3;
            dateFrom = new Date(lastQuarterYear, lastQuarterMonth, 1);
            dateTo = new Date(lastQuarterYear, lastQuarterMonth + 3, 0);
            break;
        case 'lastYear':
            dateFrom = new Date(today.getFullYear() - 1, 0, 1);
            dateTo = new Date(today.getFullYear() - 1, 11, 31);
            break;
        default:
            return;
    }
    
    document.getElementById('dateFrom').valueAsDate = dateFrom;
    document.getElementById('dateTo').valueAsDate = dateTo;
    applyDateFilter();
}

function filterDealsByDate(dealsArray, filter) {
    if (!filter.from && !filter.to) {
        return dealsArray;
    }
    
    return dealsArray.filter(deal => {
        const dealDate = new Date(deal.auth_date);
        const fromDate = filter.from ? new Date(filter.from) : null;
        const toDate = filter.to ? new Date(filter.to) : null;
        
        let valid = true;
        if (fromDate) {
            valid = valid && dealDate >= fromDate;
        }
        if (toDate) {
            const toDatePlusOne = new Date(toDate);
            toDatePlusOne.setDate(toDatePlusOne.getDate() + 1);
            valid = valid && dealDate < toDatePlusOne;
        }
        
        return valid;
    });
}

function formatDate(dateString) {
    try {
        const date = new Date(dateString);
        return date.toLocaleDateString('ru-RU');
    } catch (e) {
        return dateString;
    }
}

function formatDateForFilter(date) {
    try {
        return date.toISOString().split('T')[0];
    } catch (e) {
        return date;
    }
}